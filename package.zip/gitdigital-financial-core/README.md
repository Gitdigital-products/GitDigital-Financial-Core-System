# GitDigital Financial Core

A comprehensive decentralized loan and financial infrastructure platform built on Solana, featuring AI-powered analytics, credit scoring, compliance automation, and dynamic NFT reputation systems.

## Architecture Overview

This monorepo contains the complete GitDigital Financial Core system, including:

### Core Services

| Service | Port | Description |
|---------|------|-------------|
| Loan Engine | 3001 | Core loan processing and workflow management |
| Credit Authority | 3002 | Richards Credit scoring and evaluation |
| AI Gateway | 3004 | HustleGPT and GrowthFlow analytics integration |
| Compliance Guard | 3003 | KYC/AML verification and compliance checks |
| Tax Service | 3005 | Tax event logging and report generation |
| Infrastructure Agent | 3006 | Deployment orchestration and health monitoring |

### Frontend

- **Dashboard UI** (Port 3000): React/Next.js dashboard with Solana wallet integration

## Project Structure

```
gitdigital-financial-core/
├── apps/
│   └── dashboard-ui/           # React dashboard application
├── services/
│   ├── loan-engine/            # Core loan service
│   ├── credit-authority/       # Credit scoring service
│   ├── ai-gateway/             # AI analytics service
│   ├── compliance-guard/       # Compliance service
│   ├── tax-service/           # Tax reporting service
│   └── infrastructure/         # Deployment agent
├── packages/
│   ├── shared-types/          # TypeScript type definitions
│   ├── event-bus/             # Event communication system
│   ├── solana-client/         # Blockchain client utilities
│   └── kyc-sdk/               # KYC integration SDK
├── smart-contracts/
│   ├── loan-program/          # Anchor smart contracts
│   └── badge-authority/       # NFT badge contracts
└── docker-compose.yml          # Local development setup
```

## Getting Started

### Prerequisites

- Node.js 20+
- Docker and Docker Compose
- Solana CLI tools (for smart contract development)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/Gitdigital-products/gitdigital-financial-core.git
cd gitdigital-financial-core
```

2. Install dependencies:
```bash
npm install
```

3. Start with Docker Compose:
```bash
docker-compose up -d
```

4. Access the dashboard:
- Open http://localhost:3000

### Development

Run individual services:

```bash
# Start loan engine
cd services/loan-engine
npm run dev

# Start credit authority
cd services/credit-authority
npm run dev

# Start dashboard
cd apps/dashboard-ui
npm run dev
```

## Environment Variables

Create `.env` files for each service:

```env
# .env for loan-engine
SOLANA_RPC_URL=https://api.mainnet-beta.solana.com
CREDIT_SERVICE_URL=http://localhost:3002
COMPLIANCE_SERVICE_URL=http://localhost:3003

# .env for ai-gateway
OLLAMA_URL=http://localhost:11434
```

## API Endpoints

### Loan Engine
- `POST /api/loans` - Create new loan
- `GET /api/loans` - List loans
- `GET /api/loans/:id` - Get loan details
- `POST /api/loans/:id/repayments` - Add repayment

### Credit Authority
- `GET /api/credit/:borrower` - Get credit score
- `POST /api/credit/evaluate` - Evaluate credit

### Compliance Guard
- `POST /api/kyc/submit` - Submit KYC
- `GET /api/kyc/:address` - Get KYC status
- `POST /api/compliance/validate` - Validate action

### AI Gateway
- `GET /api/insights/:borrower` - Get AI insights
- `POST /api/ai/chat` - Chat with HustleGPT

### Tax Service
- `GET /api/tax/events/:address` - Get tax events
- `POST /api/tax/reports/generate` - Generate tax report

## Event System

The system uses an event-driven architecture with the following event types:

### Loan Events
- `loan.requested` - New loan application
- `loan.approved` - Loan approved
- `loan.funded` - Loan funded
- `loan.repayment.made` - Payment received
- `loan.repaid` - Loan fully repaid

### Credit Events
- `credit.score.updated` - Score changed
- `credit.evaluation.requested` - New evaluation

### Compliance Events
- `compliance.check.requested` - Check initiated
- `compliance.check.completed` - Check finished
- `compliance.kyc.verified` - KYC approved

### AI Events
- `analytics.insight.generated` - New insight
- `analytics.anomaly.detected` - Anomaly found

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - see LICENSE file for details

## GitHub Repositories

This system integrates with the following repositories:

- solana-kyc-compliance-sdk
- Identity-Verification-KYC-AML
- Founder-Self-Loan
- analytics-service
- richards-credit-authority
- GITDIGITAL-FINANCIAL-INFRASTRUCTURE
- Dynamic-NFT-dNFT-Framework
- AIGateway-Ollama
- solana-compliance-registry
- Proof-of-Contribution-Protocol-Core
- Decentralized-Finance-DeFi-Primitives
- BADGE-AUTHORITY

## GitHub Apps

Integrated GitHub Apps:
- infra-agent
- HustleGPT
- R-deployer
- Growthflow
- Ledger-X
- Solana Compliance Guard
- Repo-fix
- Tax AI
