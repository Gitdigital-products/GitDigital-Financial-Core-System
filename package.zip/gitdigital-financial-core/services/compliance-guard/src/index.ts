/**
 * GitDigital Financial Core - Solana Compliance Guard Service
 * 
 * This service handles compliance and KYC/AML verification:
 * - KYC verification
 * - AML screening
 * - Sanctions list checking
 * - Transaction monitoring
 * - Regulatory compliance
 * 
 * @package @gitdigital/compliance-guard
 * @version 1.0.0
 */

import express, { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import {
  KYCVerification,
  KYCStatus,
  RiskLevel,
  KYCCheck,
  ComplianceValidationRequest,
  ComplianceValidationResult,
  ComplianceAction,
  ApiResponse,
} from '@gitdigital/shared-types';
import { EventBus, ComplianceEvents, getEventBus } from '@gitdigital/event-bus';

// Service configuration
interface ComplianceConfig {
  port: number;
  kycProviderUrl: string;
  amlProviderUrl: string;
  sanctionsListUrls: string[];
  requireKYC: boolean;
  maxTransactionLimit: number;
}

const defaultConfig: ComplianceConfig = {
  port: 3003,
  kycProviderUrl: process.env.KYC_PROVIDER_URL || 'https://api.kyc-provider.com',
  amlProviderUrl: process.env.AML_PROVIDER_URL || 'https://api.aml-provider.com',
  sanctionsListUrls: [
    'https://www.treasury.gov/ofac/downloads/sdn.csv',
    'https://www.un.org/sc/suborg/en/sanctions/1267/aq_sanctions_list.csv',
  ],
  requireKYC: true,
  maxTransactionLimit: 10000,
};

/**
 * Compliance Guard Service
 * 
 * Manages compliance checks and KYC/AML verification.
 */
export class ComplianceGuard {
  private app: express.Application;
  private logger: Logger;
  private config: ComplianceConfig;
  private eventBus: EventBus;
  private kycVerifications: Map<string, KYCVerification> = new Map();
  private validationHistory: Map<string, ComplianceValidationResult[]> = new Map();

  constructor(config: Partial<ComplianceConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.app = express();
    this.logger = this.createLogger();
    this.eventBus = getEventBus();

    this.setupMiddleware();
    this.setupRoutes();
    this.setupEventHandlers();
  }

  private createLogger(): Logger {
    const winston = require('winston');
    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      this.logger.info(`Incoming request`, {
        method: req.method,
        path: req.path,
      });
      next();
    });
  }

  private setupRoutes(): void {
    this.app.get('/health', (req: Request, res: Response) => {
      res.json({ status: 'healthy', service: 'compliance-guard' });
    });

    this.app.post('/api/kyc/submit', this.submitKYC.bind(this));
    this.app.get('/api/kyc/:walletAddress', this.getKYCStatus.bind(this));
    this.app.post('/api/compliance/validate', this.validateAction.bind(this));
    this.app.get('/api/compliance/history/:walletAddress', this.getValidationHistory.bind(this));
  }

  private setupEventHandlers(): void {
    this.eventBus.subscribe(
      'compliance.check.requested',
      async (event) => {
        const payload = event.payload as {
          walletAddress: string;
          action: string;
          loanId?: string;
          metadata?: Record<string, unknown>;
        };
        await this.processComplianceCheck(payload);
      }
    );

    this.eventBus.subscribe(
      'loan.funded',
      async (event) => {
        const payload = event.payload as { borrower: string; amount: number };
        await this.logTransaction(payload.borrower, payload.amount, 'LOAN_DISBURSEMENT');
      }
    );

    this.eventBus.subscribe(
      'loan.repayment.made',
      async (event) => {
        const payload = event.payload as { borrower: string; amount: number };
        await this.logTransaction(payload.borrower, payload.amount, 'LOAN_REPAYMENT');
      }
    );
  }

  /**
   * Submit KYC application
   */
  private async submitKYC(req: Request, res: Response): Promise<void> {
    try {
      const { walletAddress, documentIds } = req.body;

      if (!walletAddress) {
        const response: ApiResponse<null> = {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Wallet address is required',
          },
          metadata: {
            timestamp: new Date(),
            requestId: uuidv4(),
          },
        };
        res.status(400).json(response);
        return;
      }

      const verification: KYCVerification = {
        id: uuidv4(),
        walletAddress,
        status: KYCStatus.PENDING,
        riskLevel: RiskLevel.MEDIUM,
        documentIds: documentIds || [],
        checks: [],
      };

      // Perform KYC checks
      const checks = await this.performKYCChecks(walletAddress, documentIds || []);
      verification.checks = checks;
      verification.status = this.determineKYCStatus(checks);
      verification.riskLevel = this.calculateRiskLevel(checks);

      this.kycVerifications.set(walletAddress, verification);

      if (verification.status === KYCStatus.VERIFIED) {
        await this.eventBus.publish({
          eventType: ComplianceEvents.KYC_VERIFIED,
          source: 'compliance-guard',
          payload: {
            walletAddress,
            verificationId: verification.id,
          },
        });
      }

      const response: ApiResponse<KYCVerification> = {
        success: true,
        data: verification,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      this.logger.info(`KYC submitted`, { walletAddress, status: verification.status });
      res.status(201).json(response);
    } catch (error) {
      this.logger.error(`Error submitting KYC`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'KYC_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get KYC status for wallet
   */
  private async getKYCStatus(req: Request, res: Response): Promise<void> {
    const { walletAddress } = req.params;

    let verification = this.kycVerifications.get(walletAddress);

    if (!verification) {
      verification = {
        id: uuidv4(),
        walletAddress,
        status: KYCStatus.NOT_STARTED,
        riskLevel: RiskLevel.MEDIUM,
        documentIds: [],
        checks: [],
      };
    }

    const response: ApiResponse<KYCVerification> = {
      success: true,
      data: verification,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Validate compliance for action
   */
  private async validateAction(req: Request, res: Response): Promise<void> {
    try {
      const validationRequest: ComplianceValidationRequest = req.body;

      const result = await this.performValidation(validationRequest);

      const history = this.validationHistory.get(validationRequest.walletAddress) || [];
      history.push(result);
      this.validationHistory.set(validationRequest.walletAddress, history);

      const response: ApiResponse<ComplianceValidationResult> = {
        success: true,
        data: result,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      res.json(response);
    } catch (error) {
      this.logger.error(`Error validating action`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get validation history
   */
  private async getValidationHistory(req: Request, res: Response): Promise<void> {
    const { walletAddress } = req.params;

    const history = this.validationHistory.get(walletAddress) || [];

    const response: ApiResponse<ComplianceValidationResult[]> = {
      success: true,
      data: history,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Process compliance check request
   */
  private async processComplianceCheck(payload: {
    walletAddress: string;
    action: string;
    loanId?: string;
    metadata?: Record<string, unknown>;
  }): Promise<void> {
    const request: ComplianceValidationRequest = {
      walletAddress: payload.walletAddress,
      action: payload.action as ComplianceAction,
      metadata: payload.metadata,
    };

    const result = await this.performValidation(request);

    await this.eventBus.publish({
      eventType: ComplianceEvents.CHECK_COMPLETED,
      source: 'compliance-guard',
      payload: {
        walletAddress: payload.walletAddress,
        action: payload.action,
        loanId: payload.loanId,
        result,
      },
    });
  }

  /**
   * Perform KYC checks
   */
  private async performKYCChecks(
    walletAddress: string,
    documentIds: string[]
  ): Promise<KYCCheck[]> {
    const checks: KYCCheck[] = [];

    // Identity verification check
    checks.push({
      checkType: 'IDENTITY_VERIFICATION',
      status: documentIds.length > 0 ? 'PASS' : 'PENDING',
      details: documentIds.length > 0 ? 'Documents provided' : 'Awaiting documents',
      timestamp: new Date(),
    });

    // Address verification check
    checks.push({
      checkType: 'ADDRESS_VERIFICATION',
      status: 'PENDING',
      details: 'Awaiting address verification',
      timestamp: new Date(),
    });

    // AML screening
    const amlCheck = await this.performAMLScreen(walletAddress);
    checks.push(amlCheck);

    // Sanctions screening
    const sanctionsCheck = await this.performSanctionsScreen(walletAddress);
    checks.push(sanctionsCheck);

    // Watchlist screening
    const watchlistCheck = await this.performWatchlistScreen(walletAddress);
    checks.push(watchlistCheck);

    return checks;
  }

  /**
   * Perform AML screening
   */
  private async performAMLScreen(walletAddress: string): Promise<KYCCheck> {
    // Simulated AML check
    const riskScore = Math.random() * 100;
    
    return {
      checkType: 'AML_SCREENING',
      status: riskScore < 70 ? 'PASS' : 'FAIL',
      details: `AML risk score: ${riskScore.toFixed(2)}`,
      timestamp: new Date(),
    };
  }

  /**
   * Perform sanctions screening
   */
  private async performSanctionsScreen(walletAddress: string): Promise<KYCCheck> {
    // Simulated sanctions check - in production, this would check against OFAC list
    return {
      checkType: 'SANCTIONS_SCREENING',
      status: 'PASS',
      details: 'No sanctions matches found',
      timestamp: new Date(),
    };
  }

  /**
   * Perform watchlist screening
   */
  private async performWatchlistScreen(walletAddress: string): Promise<KYCCheck> {
    // Simulated watchlist check
    return {
      checkType: 'WATCHLIST_SCREENING',
      status: 'PASS',
      details: 'No watchlist matches found',
      timestamp: new Date(),
    };
  }

  /**
   * Determine KYC status from checks
   */
  private determineKYCStatus(checks: KYCCheck[]): KYCStatus {
    const failedChecks = checks.filter(c => c.status === 'FAIL');
    const pendingChecks = checks.filter(c => c.status === 'PENDING');

    if (failedChecks.length > 0) {
      return KYCStatus.REJECTED;
    }

    if (pendingChecks.length > 0) {
      return KYCStatus.IN_REVIEW;
    }

    return KYCStatus.VERIFIED;
  }

  /**
   * Calculate risk level from checks
   */
  private calculateRiskLevel(checks: KYCCheck[]): RiskLevel {
    const failedChecks = checks.filter(c => c.status === 'FAIL').length;

    if (failedChecks >= 2) {
      return RiskLevel.PROHIBITED;
    }

    if (failedChecks === 1) {
      return RiskLevel.HIGH;
    }

    return RiskLevel.LOW;
  }

  /**
   * Perform compliance validation
   */
  private async performValidation(
    request: ComplianceValidationRequest
  ): Promise<ComplianceValidationResult> {
    const kyc = this.kycVerifications.get(request.walletAddress);
    
    const checks: KYCCheck[] = [];

    // KYC requirement check
    if (this.config.requireKYC) {
      const kycCheck: KYCCheck = {
        checkType: 'KYC_REQUIRED',
        status: kyc && kyc.status === KYCStatus.VERIFIED ? 'PASS' : 'FAIL',
        details: kyc ? `KYC status: ${kyc.status}` : 'No KYC on file',
        timestamp: new Date(),
      };
      checks.push(kycCheck);
    }

    // Risk level check
    if (kyc && kyc.riskLevel === RiskLevel.PROHIBITED) {
      const riskCheck: KYCCheck = {
        checkType: 'RISK_LEVEL',
        status: 'FAIL',
        details: 'Wallet is prohibited',
        timestamp: new Date(),
      };
      checks.push(riskCheck);
    }

    // Transaction limit check
    if (request.metadata?.amount) {
      const amount = request.metadata.amount as number;
      const limitCheck: KYCCheck = {
        checkType: 'TRANSACTION_LIMIT',
        status: amount <= this.config.maxTransactionLimit ? 'PASS' : 'FAIL',
        details: amount <= this.config.maxTransactionLimit 
          ? `Amount ${amount} within limit` 
          : `Amount ${amount} exceeds limit ${this.config.maxTransactionLimit}`,
        timestamp: new Date(),
      };
      checks.push(limitCheck);
    }

    const allowed = checks.every(c => c.status === 'PASS');
    const reason = allowed ? undefined : checks.find(c => c.status === 'FAIL')?.details;

    const riskLevel = allowed 
      ? (kyc?.riskLevel || RiskLevel.MEDIUM)
      : RiskLevel.HIGH;

    return {
      allowed,
      reason,
      riskLevel,
      checks,
    };
  }

  /**
   * Log transaction for monitoring
   */
  private async logTransaction(
    walletAddress: string,
    amount: number,
    eventType: string
  ): Promise<void> {
    await this.eventBus.publish({
      eventType: ComplianceEvents.CHECK_COMPLETED,
      source: 'compliance-guard',
      payload: {
        walletAddress,
        action: eventType,
        result: {
          allowed: true,
          riskLevel: RiskLevel.LOW,
          checks: [],
        },
      },
    });
  }

  /**
   * Start the service
   */
  start(): void {
    this.app.listen(this.config.port, () => {
      this.logger.info(`Compliance Guard service started`, {
        port: this.config.port,
      });
    });
  }
}

export function createComplianceGuard(
  config?: Partial<ComplianceConfig>
): ComplianceGuard {
  return new ComplianceGuard(config);
}

export default ComplianceGuard;
