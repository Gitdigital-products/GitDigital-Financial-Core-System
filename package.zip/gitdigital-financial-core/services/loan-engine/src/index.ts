/**
 * GitDigital Financial Core - Loan Engine Service
 * 
 * This service handles the core loan functionality including:
 * - Loan application processing
 * - Workflow management
 * - Loan state transitions
 * - Integration with credit authority and compliance
 * 
 * @package @gitdigital/loan-engine
 * @version 1.0.0
 */

import express, { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import {
  LoanRequest,
  LoanStatus,
  LoanType,
  LoanRepayment,
  RepaymentStatus,
  RiskRating,
  ApiResponse,
  CreditEvaluationResult,
  ComplianceValidationResult,
} from '@gitdigital/shared-types';
import { EventBus, LoanEvents } from '@gitdigital/event-bus';

// Service configuration
interface LoanEngineConfig {
  port: number;
  solanaRpcUrl: string;
  creditServiceUrl: string;
  complianceServiceUrl: string;
}

// Default configuration
const defaultConfig: LoanEngineConfig = {
  port: 3001,
  solanaRpcUrl: process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com',
  creditServiceUrl: process.env.CREDIT_SERVICE_URL || 'http://localhost:3002',
  complianceServiceUrl: process.env.COMPLIANCE_SERVICE_URL || 'http://localhost:3003',
};

/**
 * Loan Engine Service
 * 
 * Manages the complete loan lifecycle from application to repayment.
 */
export class LoanEngine {
  private app: express.Application;
  private logger: Logger;
  private config: LoanEngineConfig;
  private eventBus: EventBus;
  private loans: Map<string, LoanRequest> = new Map();
  private repayments: Map<string, LoanRepayment[]> = new Map();

  constructor(config: Partial<LoanEngineConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.app = express();
    this.logger = this.createLogger();
    this.eventBus = getEventBus();

    this.setupMiddleware();
    this.setupRoutes();
    this.setupEventHandlers();
  }

  private createLogger(): Logger {
    const winston = require('winston');
    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      this.logger.info(`Incoming request`, {
        method: req.method,
        path: req.path,
      });
      next();
    });
  }

  private setupRoutes(): void {
    // Health check
    this.app.get('/health', (req: Request, res: Response) => {
      res.json({ status: 'healthy', service: 'loan-engine' });
    });

    // Loan endpoints
    this.app.post('/api/loans', this.createLoan.bind(this));
    this.app.get('/api/loans', this.listLoans.bind(this));
    this.app.get('/api/loans/:id', this.getLoan.bind(this));
    this.app.put('/api/loans/:id/status', this.updateLoanStatus.bind(this));
    this.app.post('/api/loans/:id/repayments', this.addRepayment.bind(this));
    this.app.get('/api/loans/:id/repayments', this.getRepayments.bind(this));
  }

  private setupEventHandlers(): void {
    // Handle credit score updates
    this.eventBus.subscribe(
      'credit.score.updated',
      async (event) => {
        const payload = event.payload as { borrower: string; newScore: number };
        await this.handleCreditScoreUpdate(payload.borrower, payload.newScore);
      }
    );

    // Handle compliance validations
    this.eventBus.subscribe(
      'compliance.check.completed',
      async (event) => {
        const payload = event.payload as {
          walletAddress: string;
          loanId: string;
          result: ComplianceValidationResult;
        };
        await this.handleComplianceResult(payload.loanId, payload.result);
      }
    );

    // Handle governance approvals
    this.eventBus.subscribe(
      'governance.proposal.executed',
      async (event) => {
        const payload = event.payload as {
          proposalId: string;
          proposalType: string;
        };
        if (payload.proposalType === 'LOAN_APPROVAL') {
          await this.handleGovernanceApproval(payload.proposalId);
        }
      }
    );
  }

  /**
   * Create a new loan application
   */
  private async createLoan(req: Request, res: Response): Promise<void> {
    try {
      const {
        borrower,
        loanType,
        principalAmount,
        collateralAmount,
        collateralToken,
        interestRate,
        termMonths,
        purpose,
      } = req.body;

      // Validate required fields
      if (!borrower || !loanType || !principalAmount || !interestRate || !termMonths) {
        const response: ApiResponse<null> = {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Missing required fields',
          },
          metadata: {
            timestamp: new Date(),
            requestId: uuidv4(),
          },
        };
        res.status(400).json(response);
        return;
      }

      // Create loan request
      const loan: LoanRequest = {
        id: uuidv4(),
        borrower,
        loanType: loanType as LoanType,
        principalAmount,
        collateralAmount,
        collateralToken,
        interestRate,
        termMonths,
        purpose,
        status: LoanStatus.APPLICATION_SUBMITTED,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      // Store loan
      this.loans.set(loan.id, loan);
      this.repayments.set(loan.id, []);

      // Publish loan requested event
      await this.eventBus.publish({
        eventType: LoanEvents.REQUESTED,
        source: 'loan-engine',
        payload: {
          loanId: loan.id,
          borrower: loan.borrower,
          amount: loan.principalAmount,
        },
      });

      // Initiate compliance check
      await this.initiateComplianceCheck(loan);

      const response: ApiResponse<LoanRequest> = {
        success: true,
        data: loan,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      this.logger.info(`Loan created`, { loanId: loan.id, borrower });
      res.status(201).json(response);
    } catch (error) {
      this.logger.error(`Error creating loan`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Initiate compliance check for loan
   */
  private async initiateComplianceCheck(loan: LoanRequest): Promise<void> {
    await this.eventBus.publish({
      eventType: 'compliance.check.requested',
      source: 'loan-engine',
      payload: {
        walletAddress: loan.borrower,
        action: 'LOAN_REQUEST',
        loanId: loan.id,
        metadata: {
          principalAmount: loan.principalAmount,
          collateralAmount: loan.collateralAmount,
        },
      },
    });
  }

  /**
   * Handle compliance check result
   */
  private async handleComplianceResult(
    loanId: string,
    result: ComplianceValidationResult
  ): Promise<void> {
    const loan = this.loans.get(loanId);
    if (!loan) return;

    if (!result.allowed) {
      await this.updateLoanStatusInternal(loan, LoanStatus.REJECTED);
      await this.eventBus.publish({
        eventType: LoanEvents.REJECTED,
        source: 'loan-engine',
        payload: {
          loanId: loan.id,
          borrower: loan.borrower,
          reason: result.reason,
        },
      });
    } else {
      await this.updateLoanStatusInternal(loan, LoanStatus.KYC_VERIFIED);
      await this.requestCreditEvaluation(loan);
    }
  }

  /**
   * Request credit evaluation from credit authority
   */
  private async requestCreditEvaluation(loan: LoanRequest): Promise<void> {
    await this.eventBus.publish({
      eventType: 'credit.evaluation.requested',
      source: 'loan-engine',
      payload: {
        borrower: loan.borrower,
        loanAmount: loan.principalAmount,
        loanPurpose: loan.purpose,
        requestedInterestRate: loan.interestRate,
        collateralAmount: loan.collateralAmount,
      },
    });
  }

  /**
   * Handle credit score update
   */
  private async handleCreditScoreUpdate(
    borrower: string,
    newScore: number
  ): Promise<void> {
    // Find loans for this borrower that need credit evaluation
    const loansToUpdate = Array.from(this.loans.values()).filter(
      (loan) =>
        loan.borrower === borrower &&
        (loan.status === LoanStatus.KYC_VERIFIED ||
          loan.status === LoanStatus.CREDIT_EVALUATION)
    );

    for (const loan of loansToUpdate) {
      // Determine risk rating based on credit score
      const riskRating = this.calculateRiskRating(newScore);
      const approvedInterestRate = this.calculateApprovedRate(
        loan.interestRate,
        riskRating
      );

      loan.creditScore = newScore;
      loan.riskRating = riskRating;
      loan.interestRate = approvedInterestRate;
      loan.status = LoanStatus.UNDERWRITING;
      loan.updatedAt = new Date();

      await this.eventBus.publish({
        eventType: LoanEvents.APPROVED,
        source: 'loan-engine',
        payload: {
          loanId: loan.id,
          borrower: loan.borrower,
          interestRate: loan.interestRate,
          riskRating: loan.riskRating,
          creditScore: loan.creditScore,
        },
      });

      this.logger.info(`Loan approved`, {
        loanId: loan.id,
        creditScore: newScore,
        riskRating,
      });
    }
  }

  /**
   * Calculate risk rating from credit score
   */
  private calculateRiskRating(score: number): RiskRating {
    if (score >= 800) return RiskRating.AAA;
    if (score >= 750) return RiskRating.AA;
    if (score >= 700) return RiskRating.A;
    if (score >= 650) return RiskRating.BBB;
    if (score >= 600) return RiskRating.BB;
    if (score >= 550) return RiskRating.B;
    if (score >= 500) return RiskRating.CCC;
    if (score >= 450) return RiskRating.CC;
    if (score >= 400) return RiskRating.C;
    return RiskRating.D;
  }

  /**
   * Calculate approved interest rate based on risk
   */
  private calculateApprovedRate(
    requestedRate: number,
    riskRating: RiskRating
  ): number {
    const riskAdjustments: Record<RiskRating, number> = {
      [RiskRating.AAA]: -0.5,
      [RiskRating.AA]: -0.25,
      [RiskRating.A]: 0,
      [RiskRating.BBB]: 0.25,
      [RiskRating.BB]: 0.5,
      [RiskRating.B]: 1.0,
      [RiskRating.CCC]: 1.5,
      [RiskRating.CC]: 2.0,
      [RiskRating.C]: 2.5,
      [RiskRating.D]: 3.0,
    };

    return requestedRate + (riskAdjustments[riskRating] || 0);
  }

  /**
   * Handle governance approval
   */
  private async handleGovernanceApproval(proposalId: string): Promise<void> {
    const loansToFund = Array.from(this.loans.values()).filter(
      (loan) => loan.governanceProposalId === proposalId
    );

    for (const loan of loansToFund) {
      await this.updateLoanStatusInternal(loan, LoanStatus.FUNDED);

      await this.eventBus.publish({
        eventType: LoanEvents.FUNDED,
        source: 'loan-engine',
        payload: {
          loanId: loan.id,
          borrower: loan.borrower,
          amount: loan.principalAmount,
        },
      });

      this.logger.info(`Loan funded`, { loanId: loan.id });
    }
  }

  /**
   * Update loan status internally
   */
  private async updateLoanStatusInternal(
    loan: LoanRequest,
    status: LoanStatus
  ): Promise<void> {
    loan.status = status;
    loan.updatedAt = new Date();
    this.loans.set(loan.id, loan);
  }

  /**
   * List all loans
   */
  private async listLoans(req: Request, res: Response): Promise<void> {
    const { borrower, status, limit = 50, offset = 0 } = req.query;

    let loans = Array.from(this.loans.values());

    if (borrower) {
      loans = loans.filter((loan) => loan.borrower === borrower);
    }

    if (status) {
      loans = loans.filter((loan) => loan.status === status);
    }

    const total = loans.length;
    const paginatedLoans = loans.slice(Number(offset), Number(offset) + Number(limit));

    const response: ApiResponse<LoanRequest[]> = {
      success: true,
      data: paginatedLoans,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Get loan by ID
   */
  private async getLoan(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const loan = this.loans.get(id);

    if (!loan) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Loan not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    const response: ApiResponse<LoanRequest> = {
      success: true,
      data: loan,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Update loan status
   */
  private async updateLoanStatus(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const { status } = req.body;

    const loan = this.loans.get(id);
    if (!loan) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Loan not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    await this.updateLoanStatusInternal(loan, status as LoanStatus);

    const response: ApiResponse<LoanRequest> = {
      success: true,
      data: loan,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Add repayment to loan
   */
  private async addRepayment(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const { amount, principalPaid, interestPaid, transactionHash } = req.body;

    const loan = this.loans.get(id);
    if (!loan) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Loan not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    const repayment: LoanRepayment = {
      id: uuidv4(),
      loanId: id,
      amount,
      principalPaid,
      interestPaid,
      penaltyPaid: 0,
      paymentDate: new Date(),
      transactionHash,
      status: RepaymentStatus.CONFIRMED,
    };

    const repayments = this.repayments.get(id) || [];
    repayments.push(repayment);
    this.repayments.set(id, repayments);

    // Update loan status if fully repaid
    const totalRepaid = repayments.reduce((sum, r) => sum + r.amount, 0);
    if (totalRepaid >= loan.principalAmount) {
      await this.updateLoanStatusInternal(loan, LoanStatus.REPAID);
      
      await this.eventBus.publish({
        eventType: LoanEvents.REPAID,
        source: 'loan-engine',
        payload: {
          loanId: loan.id,
          borrower: loan.borrower,
          totalRepaid,
        },
      });
    } else {
      await this.updateLoanStatusInternal(loan, LoanStatus.REPAYING);
    }

    await this.eventBus.publish({
      eventType: LoanEvents.REPAYMENT_MADE,
      source: 'loan-engine',
      payload: {
        loanId: loan.id,
        repaymentId: repayment.id,
        amount,
      },
    });

    const response: ApiResponse<LoanRepayment> = {
      success: true,
      data: repayment,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.status(201).json(response);
  }

  /**
   * Get repayments for loan
   */
  private async getRepayments(req: Request, res: Response): Promise<void> {
    const { id } = req.params;

    const repayments = this.repayments.get(id) || [];

    const response: ApiResponse<LoanRepayment[]> = {
      success: true,
      data: repayments,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Start the service
   */
  start(): void {
    this.app.listen(this.config.port, () => {
      this.logger.info(`Loan Engine service started`, {
        port: this.config.port,
      });
    });
  }
}

// Export factory function
export function createLoanEngine(
  config?: Partial<LoanEngineConfig>
): LoanEngine {
  return new LoanEngine(config);
}

// Export default
export default LoanEngine;
