/**
 * GitDigital Financial Core - Infrastructure Agent Service
 * 
 * This service handles infrastructure management:
 * - Service deployment orchestration
 * - Health monitoring
 * - Auto-scaling
 * - Deployment approvals
 * 
 * @package @gitdigital/infrastructure
 * @version 1.0.0
 */

import express, { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import {
  ServiceHealth,
  ServiceStatus,
  DeploymentConfig,
  ApiResponse,
} from '@gitdigital/shared-types';
import { EventBus, InfraEvents, getEventBus } from '@gitdigital/event-bus';

// Service configuration
interface InfraConfig {
  port: number;
  dockerHost: string;
  monitoringInterval: number;
  autoScaleEnabled: boolean;
}

const defaultConfig: InfraConfig = {
  port: 3006,
  dockerHost: process.env.DOCKER_HOST || 'unix:///var/run/docker.sock',
  monitoringInterval: 30000,
  autoScaleEnabled: true,
};

/**
 * Infrastructure Agent Service
 * 
 * Manages service deployment, health monitoring, and orchestration.
 */
export class InfrastructureAgent {
  private app: express.Application;
  private logger: Logger;
  private config: InfraConfig;
  private eventBus: EventBus;
  private services: Map<string, ServiceHealth> = new Map();
  private deployments: Map<string, DeploymentConfig> = new Map();
  private monitoringInterval: NodeJS.Timeout | null = null;

  constructor(config: Partial<InfraConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.app = express();
    this.logger = this.createLogger();
    this.eventBus = getEventBus();

    this.setupMiddleware();
    this.setupRoutes();
    this.setupEventHandlers();
    this.initializeServices();
  }

  private createLogger(): Logger {
    const winston = require('winston');
    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      this.logger.info(`Incoming request`, {
        method: req.method,
        path: req.path,
      });
      next();
    });
  }

  private setupRoutes(): void {
    this.app.get('/health', (req: Request, res: Response) => {
      res.json({ status: 'healthy', service: 'infrastructure-agent' });
    });

    this.app.get('/api/services', this.listServices.bind(this));
    this.app.get('/api/services/:name', this.getServiceHealth.bind(this));
    this.app.post('/api/deploy', this.deployService.bind(this));
    this.app.get('/api/deployments', this.listDeployments.bind(this));
    this.app.get('/api/deployments/:id', this.getDeployment.bind(this));
    this.app.post('/api/deployments/:id/approve', this.approveDeployment.bind(this));
    this.app.post('/api/deployments/:id/reject', this.rejectDeployment.bind(this));
    this.app.get('/api/status', this.getSystemStatus.bind(this));
  }

  private setupEventHandlers(): void {
    this.eventBus.subscribe('compliance.check.completed', async (event) => {
      const payload = event.payload as { result: { allowed: boolean } };
      
      if (payload.result.allowed) {
        await this.eventBus.publish({
          eventType: InfraEvents.SERVICE_DEPLOYED,
          source: 'infrastructure',
          payload: {
            service: 'loan-engine',
            status: 'ready',
          },
        });
      }
    });
  }

  private initializeServices(): void {
    // Initialize default services with healthy status
    const defaultServices = [
      'loan-engine',
      'credit-authority',
      'compliance-guard',
      'ai-gateway',
      'tax-service',
      'governance-engine',
      'nft-service',
    ];

    for (const service of defaultServices) {
      this.services.set(service, {
        serviceName: service,
        status: ServiceStatus.HEALTHY,
        uptime: Date.now(),
        lastCheck: new Date(),
        responseTime: 100,
        errorRate: 0,
      });
    }

    // Start health monitoring
    this.startHealthMonitoring();
  }

  /**
   * List all services
   */
  private async listServices(req: Request, res: Response): Promise<void> {
    const services = Array.from(this.services.values());

    const response: ApiResponse<ServiceHealth[]> = {
      success: true,
      data: services,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Get service health
   */
  private async getServiceHealth(req: Request, res: Response): Promise<void> {
    const { name } = req.params;
    const service = this.services.get(name);

    if (!service) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Service not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    const response: ApiResponse<ServiceHealth> = {
      success: true,
      data: service,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Deploy service
   */
  private async deployService(req: Request, res: Response): Promise<void> {
    try {
      const deploymentConfig: DeploymentConfig = req.body;

      if (!deploymentConfig.serviceName) {
        const response: ApiResponse<null> = {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Service name is required',
          },
          metadata: {
            timestamp: new Date(),
            requestId: uuidv4(),
          },
        };
        res.status(400).json(response);
        return;
      }

      const deploymentId = uuidv4();
      deploymentConfig.version = deploymentConfig.version || '1.0.0';
      deploymentConfig.replicas = deploymentConfig.replicas || 1;
      deploymentConfig.resources = deploymentConfig.resources || {
        cpu: '500m',
        memory: '512Mi',
      };

      this.deployments.set(deploymentId, deploymentConfig);

      // Simulate deployment
      await this.simulateDeployment(deploymentId, deploymentConfig);

      const response: ApiResponse<DeploymentConfig & { deploymentId: string }> = {
        success: true,
        data: { ...deploymentConfig, deploymentId },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      this.logger.info(`Deployment initiated`, {
        deploymentId,
        serviceName: deploymentConfig.serviceName,
      });

      res.status(201).json(response);
    } catch (error) {
      this.logger.error(`Error deploying service`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'DEPLOYMENT_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * List deployments
   */
  private async listDeployments(req: Request, res: Response): Promise<void> {
    const deployments = Array.from(this.deployments.values());

    const response: ApiResponse<DeploymentConfig[]> = {
      success: true,
      data: deployments,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Get deployment
   */
  private async getDeployment(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const deployment = this.deployments.get(id);

    if (!deployment) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Deployment not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    const response: ApiResponse<DeploymentConfig> = {
      success: true,
      data: deployment,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Approve deployment
   */
  private async approveDeployment(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const deployment = this.deployments.get(id);

    if (!deployment) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Deployment not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    // Update service health
    this.services.set(deployment.serviceName, {
      serviceName: deployment.serviceName,
      status: ServiceStatus.HEALTHY,
      uptime: Date.now(),
      lastCheck: new Date(),
      responseTime: 100,
      errorRate: 0,
    });

    await this.eventBus.publish({
      eventType: InfraEvents.SERVICE_DEPLOYED,
      source: 'infrastructure',
      payload: {
        serviceName: deployment.serviceName,
        version: deployment.version,
        environment: deployment.environment,
      },
    });

    const response: ApiResponse<{ approved: boolean; serviceName: string }> = {
      success: true,
      data: {
        approved: true,
        serviceName: deployment.serviceName,
      },
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    this.logger.info(`Deployment approved`, {
      deploymentId: id,
      serviceName: deployment.serviceName,
    });

    res.json(response);
  }

  /**
   * Reject deployment
   */
  private async rejectDeployment(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const { reason } = req.body;
    const deployment = this.deployments.get(id);

    if (!deployment) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Deployment not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    const response: ApiResponse<{ rejected: boolean; serviceName: string; reason: string }> = {
      success: true,
      data: {
        rejected: true,
        serviceName: deployment.serviceName,
        reason: reason || 'Deployment rejected',
      },
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    this.logger.info(`Deployment rejected`, {
      deploymentId: id,
      serviceName: deployment.serviceName,
      reason,
    });

    res.json(response);
  }

  /**
   * Get system status
   */
  private async getSystemStatus(req: Request, res: Response): Promise<void> {
    const services = Array.from(this.services.values());
    
    const healthyCount = services.filter(s => s.status === ServiceStatus.HEALTHY).length;
    const degradedCount = services.filter(s => s.status === ServiceStatus.DEGRADED).length;
    const unhealthyCount = services.filter(s => s.status === ServiceStatus.UNHEALTHY).length;

    const response: ApiResponse<{
      overallStatus: ServiceStatus;
      services: {
        total: number;
        healthy: number;
        degraded: number;
        unhealthy: number;
      };
      deployments: number;
    }> = {
      success: true,
      data: {
        overallStatus: unhealthyCount > 0 
          ? ServiceStatus.UNHEALTHY 
          : degradedCount > 0 
            ? ServiceStatus.DEGRADED 
            : ServiceStatus.HEALTHY,
        services: {
          total: services.length,
          healthy: healthyCount,
          degraded: degradedCount,
          unhealthy: unhealthyCount,
        },
        deployments: this.deployments.size,
      },
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Simulate deployment process
   */
  private async simulateDeployment(
    deploymentId: string,
    config: DeploymentConfig
  ): Promise<void> {
    // In production, this would use Docker API to deploy containers
    this.logger.info(`Simulating deployment`, {
      deploymentId,
      serviceName: config.serviceName,
    });
  }

  /**
   * Start health monitoring
   */
  private startHealthMonitoring(): void {
    if (this.monitoringInterval) {
      return;
    }

    this.monitoringInterval = setInterval(async () => {
      await this.performHealthChecks();
    }, this.config.monitoringInterval);

    this.logger.info(`Health monitoring started`, {
      interval: this.config.monitoringInterval,
    });
  }

  /**
   * Perform health checks on all services
   */
  private async performHealthChecks(): Promise<void> {
    for (const [name, health] of this.services.entries()) {
      // Simulate health check
      const isHealthy = Math.random() > 0.05;
      
      const newHealth: ServiceHealth = {
        ...health,
        status: isHealthy ? ServiceStatus.HEALTHY : ServiceStatus.DEGRADED,
        lastCheck: new Date(),
        responseTime: Math.floor(Math.random() * 200) + 50,
        errorRate: isHealthy ? 0 : Math.random() * 5,
      };

      this.services.set(name, newHealth);

      if (health.status !== newHealth.status) {
        await this.eventBus.publish({
          eventType: InfraEvents.SERVICE_HEALTH_CHANGED,
          source: 'infrastructure',
          payload: {
            serviceName: name,
            oldStatus: health.status,
            newStatus: newHealth.status,
          },
        });
      }

      // Check for auto-scaling
      if (this.config.autoScaleEnabled && newHealth.errorRate > 3) {
        await this.triggerAutoScale(name);
      }
    }
  }

  /**
   * Trigger auto-scaling
   */
  private async triggerAutoScale(serviceName: string): Promise<void> {
    await this.eventBus.publish({
      eventType: InfraEvents.SCALING_TRIGGERED,
      source: 'infrastructure',
      payload: {
        serviceName,
        reason: 'High error rate',
        timestamp: new Date(),
      },
    });

    this.logger.info(`Auto-scaling triggered`, { serviceName });
  }

  /**
   * Stop health monitoring
   */
  stopHealthMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
  }

  /**
   * Start the service
   */
  start(): void {
    this.app.listen(this.config.port, () => {
      this.logger.info(`Infrastructure Agent service started`, {
        port: this.config.port,
      });
    });
  }
}

export function createInfrastructureAgent(
  config?: Partial<InfraConfig>
): InfrastructureAgent {
  return new InfrastructureAgent(config);
}

export default InfrastructureAgent;
