/**
 * GitDigital Financial Core - Tax AI Service
 * 
 * This service handles tax-related functionality:
 * - Transaction tax event logging
 * - Tax report generation
 * - Income/expense categorization
 * - Year-end tax documents
 * 
 * @package @gitdigital/tax-service
 * @version 1.0.0
 */

import express, { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import {
  TaxEvent,
  TaxEventType,
  TaxReport,
  TaxReportFormat,
  ApiResponse,
} from '@gitdigital/shared-types';
import { EventBus, TaxEvents, getEventBus } from '@gitdigital/event-bus';

// Service configuration
interface TaxServiceConfig {
  port: number;
  taxYear: number;
  supportedTokens: string[];
  defaultTokenPrice: number;
}

const defaultConfig: TaxServiceConfig = {
  port: 3005,
  taxYear: new Date().getFullYear(),
  supportedTokens: ['SOL', 'USDC', 'BTC', 'ETH'],
  defaultTokenPrice: 1,
};

/**
 * Tax AI Service
 * 
 * Manages tax event tracking and report generation.
 */
export class TaxService {
  private app: express.Application;
  private logger: Logger;
  private config: TaxServiceConfig;
  private eventBus: EventBus;
  private taxEvents: Map<string, TaxEvent[]> = new Map();
  private reports: Map<string, TaxReport> = new Map();

  constructor(config: Partial<TaxServiceConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.app = express();
    this.logger = this.createLogger();
    this.eventBus = getEventBus();

    this.setupMiddleware();
    this.setupRoutes();
    this.setupEventHandlers();
  }

  private createLogger(): Logger {
    const winston = require('winston');
    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      this.logger.info(`Incoming request`, {
        method: req.method,
        path: req.path,
      });
      next();
    });
  }

  private setupRoutes(): void {
    this.app.get('/health', (req: Request, res: Response) => {
      res.json({ status: 'healthy', service: 'tax-service' });
    });

    this.app.get('/api/tax/events/:walletAddress', this.getTaxEvents.bind(this));
    this.app.post('/api/tax/events', this.logTaxEvent.bind(this));
    this.app.get('/api/tax/reports/:walletAddress', this.getTaxReports.bind(this));
    this.app.post('/api/tax/reports/generate', this.generateTaxReport.bind(this));
    this.app.get('/api/tax/reports/:walletAddress/:reportId/download', this.downloadReport.bind(this));
  }

  private setupEventHandlers(): void {
    this.eventBus.subscribe('loan.funded', async (event) => {
      const payload = event.payload as { borrower: string; amount: number; transactionHash: string };
      await this.logTaxEventInternal(
        payload.borrower,
        TaxEventType.LOAN_DISBURSEMENT,
        payload.amount,
        'SOL',
        payload.transactionHash
      );
    });

    this.eventBus.subscribe('loan.repayment.made', async (event) => {
      const payload = event.payload as { borrower: string; amount: number; transactionHash: string };
      await this.logTaxEventInternal(
        payload.borrower,
        TaxEventType.LOAN_REPAYMENT,
        payload.amount,
        'SOL',
        payload.transactionHash
      );
    });

    this.eventBus.subscribe('loan.repaid', async (event) => {
      const payload = event.payload as { borrower: string; totalRepaid: number };
      await this.logTaxEventInternal(
        payload.borrower,
        TaxEventType.INTEREST_PAYMENT,
        payload.totalRepaid * 0.1,
        'SOL',
        ''
      );
    });

    this.eventBus.subscribe('nft.minted', async (event) => {
      const payload = event.payload as { owner: string; loanId?: string };
      await this.logTaxEventInternal(
        payload.owner,
        TaxEventType.NFT_MINT,
        0,
        'SOL',
        ''
      );
    });

    this.eventBus.subscribe('governance.proposal.executed', async (event) => {
      const payload = event.payload as { proposer?: string };
      if (payload.proposer) {
        await this.logTaxEventInternal(
          payload.proposer,
          TaxEventType.GOVERNANCE_REWARD,
          100,
          'SOL',
          ''
        );
      }
    });
  }

  /**
   * Get tax events for wallet
   */
  private async getTaxEvents(req: Request, res: Response): Promise<void> {
    const { walletAddress } = req.params;
    const { year, type, limit = 100, offset = 0 } = req.query;

    let events = this.taxEvents.get(walletAddress) || [];

    if (year) {
      events = events.filter(e => e.taxYear === Number(year));
    }

    if (type) {
      events = events.filter(e => e.eventType === type);
    }

    const total = events.length;
    const paginatedEvents = events.slice(Number(offset), Number(offset) + Number(limit));

    const response: ApiResponse<TaxEvent[]> = {
      success: true,
      data: paginatedEvents,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Log tax event
   */
  private async logTaxEvent(req: Request, res: Response): Promise<void> {
    try {
      const {
        walletAddress,
        eventType,
        amount,
        token,
        transactionHash,
      } = req.body;

      if (!walletAddress || !eventType) {
        const response: ApiResponse<null> = {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Wallet address and event type are required',
          },
          metadata: {
            timestamp: new Date(),
            requestId: uuidv4(),
          },
        };
        res.status(400).json(response);
        return;
      }

      const taxEvent = await this.logTaxEventInternal(
        walletAddress,
        eventType as TaxEventType,
        amount || 0,
        token || 'SOL',
        transactionHash || ''
      );

      const response: ApiResponse<TaxEvent> = {
        success: true,
        data: taxEvent,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      await this.eventBus.publish({
        eventType: TaxEvents.EVENT_LOGGED,
        source: 'tax-service',
        payload: taxEvent,
      });

      res.status(201).json(response);
    } catch (error) {
      this.logger.error(`Error logging tax event`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'LOG_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get tax reports
   */
  private async getTaxReports(req: Request, res: Response): Promise<void> {
    const { walletAddress } = req.params;

    const reports = Array.from(this.reports.values()).filter(
      r => r.walletAddress === walletAddress
    );

    const response: ApiResponse<TaxReport[]> = {
      success: true,
      data: reports,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Generate tax report
   */
  private async generateTaxReport(req: Request, res: Response): Promise<void> {
    try {
      const { walletAddress, taxYear, format } = req.body;

      if (!walletAddress) {
        const response: ApiResponse<null> = {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Wallet address is required',
          },
          metadata: {
            timestamp: new Date(),
            requestId: uuidv4(),
          },
        };
        res.status(400).json(response);
        return;
      }

      const events = this.taxEvents.get(walletAddress) || [];
      const yearEvents = events.filter(e => e.taxYear === (taxYear || this.config.taxYear));

      const totalIncome = yearEvents
        .filter(e => this.isIncomeEvent(e.eventType))
        .reduce((sum, e) => sum + e.usdValue, 0);

      const totalExpenses = yearEvents
        .filter(e => this.isExpenseEvent(e.eventType))
        .reduce((sum, e) => sum + e.usdValue, 0);

      const report: TaxReport = {
        id: uuidv4(),
        walletAddress,
        taxYear: taxYear || this.config.taxYear,
        generatedAt: new Date(),
        events: yearEvents,
        totalIncome,
        totalExpenses,
        netGainLoss: totalIncome - totalExpenses,
        format: format as TaxReportFormat || TaxReportFormat.JSON,
      };

      this.reports.set(report.id, report);

      await this.eventBus.publish({
        eventType: TaxEvents.REPORT_GENERATED,
        source: 'tax-service',
        payload: {
          walletAddress,
          reportId: report.id,
          taxYear: report.taxYear,
        },
      });

      const response: ApiResponse<TaxReport> = {
        success: true,
        data: report,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      res.status(201).json(response);
    } catch (error) {
      this.logger.error(`Error generating tax report`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'REPORT_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Download tax report
   */
  private async downloadReport(req: Request, res: Response): Promise<void> {
    const { walletAddress, reportId } = req.params;
    const { format } = req.query;

    const report = this.reports.get(reportId);

    if (!report || report.walletAddress !== walletAddress) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Report not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    const reportFormat = (format as TaxReportFormat) || report.format;

    switch (reportFormat) {
      case TaxReportFormat.CSV:
        const csv = this.convertToCSV(report);
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename=tax_report_${report.taxYear}.csv`);
        res.send(csv);
        break;

      case TaxReportFormat.JSON:
      default:
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename=tax_report_${report.taxYear}.json`);
        res.json(report);
    }
  }

  /**
   * Log tax event internally
   */
  private async logTaxEventInternal(
    walletAddress: string,
    eventType: TaxEventType,
    amount: number,
    token: string,
    transactionHash: string
  ): Promise<TaxEvent> {
    const usdValue = amount * this.config.defaultTokenPrice;

    const taxEvent: TaxEvent = {
      id: uuidv4(),
      walletAddress,
      eventType,
      amount,
      token,
      usdValue,
      transactionHash,
      timestamp: new Date(),
      taxYear: new Date().getFullYear(),
    };

    const events = this.taxEvents.get(walletAddress) || [];
    events.push(taxEvent);
    this.taxEvents.set(walletAddress, events);

    return taxEvent;
  }

  /**
   * Check if event type is income
   */
  private isIncomeEvent(eventType: TaxEventType): boolean {
    return [
      TaxEventType.LOAN_DISBURSEMENT,
      TaxEventType.NFT_SALE,
      TaxEventType.GOVERNANCE_REWARD,
    ].includes(eventType);
  }

  /**
   * Check if event type is expense
   */
  private isExpenseEvent(eventType: TaxEventType): boolean {
    return [
      TaxEventType.LOAN_REPAYMENT,
      TaxEventType.INTEREST_PAYMENT,
      TaxEventType.COLLATERAL_WITHDRAWAL,
    ].includes(eventType);
  }

  /**
   * Convert report to CSV
   */
  private convertToCSV(report: TaxReport): string {
    const headers = ['Date', 'Event Type', 'Amount', 'Token', 'USD Value', 'Transaction Hash'];
    const rows = report.events.map(e => [
      e.timestamp.toISOString(),
      e.eventType,
      e.amount.toString(),
      e.token,
      e.usdValue.toString(),
      e.transactionHash,
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  /**
   * Start the service
   */
  start(): void {
    this.app.listen(this.config.port, () => {
      this.logger.info(`Tax AI service started`, {
        port: this.config.port,
      });
    });
  }
}

export function createTaxService(
  config?: Partial<TaxServiceConfig>
): TaxService {
  return new TaxService(config);
}

export default TaxService;
