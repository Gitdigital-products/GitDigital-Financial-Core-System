/**
 * GitDigital Financial Core - Richards Credit Authority Service
 * 
 * This service handles credit scoring and evaluation:
 * - Credit score calculation
 * - Risk assessment
 * - Credit history tracking
 * - Integration with Proof of Contribution Protocol
 * 
 * @package @gitdigital/credit-authority
 * @version 1.0.0
 */

import express, { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import {
  CreditScore,
  CreditTier,
  CreditFactor,
  CreditHistoryEntry,
  CreditEvaluationRequest,
  CreditEvaluationResult,
  RiskRating,
  ApiResponse,
  LoanStatus,
} from '@gitdigital/shared-types';
import { EventBus, CreditEvents, getEventBus } from '@gitdigital/event-bus';

// Service configuration
interface CreditAuthorityConfig {
  port: number;
  minScore: number;
  maxScore: number;
  baseScore: number;
  maxLoanToIncomeRatio: number;
}

const defaultConfig: CreditAuthorityConfig = {
  port: 3002,
  minScore: 300,
  maxScore: 850,
  baseScore: 500,
  maxLoanToIncomeRatio: 0.36,
};

/**
 * Credit Authority Service
 * 
 * Manages credit scoring and evaluation for borrowers.
 */
export class CreditAuthority {
  private app: express.Application;
  private logger: Logger;
  private config: CreditAuthorityConfig;
  private eventBus: EventBus;
  private creditScores: Map<string, CreditScore> = new Map();
  private evaluations: Map<string, CreditEvaluationResult> = new Map();

  constructor(config: Partial<CreditAuthorityConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.app = express();
    this.logger = this.createLogger();
    this.eventBus = getEventBus();

    this.setupMiddleware();
    this.setupRoutes();
    this.setupEventHandlers();
  }

  private createLogger(): Logger {
    const winston = require('winston');
    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      this.logger.info(`Incoming request`, {
        method: req.method,
        path: req.path,
      });
      next();
    });
  }

  private setupRoutes(): void {
    this.app.get('/health', (req: Request, res: Response) => {
      res.json({ status: 'healthy', service: 'credit-authority' });
    });

    this.app.get('/api/credit/:borrower', this.getCreditScore.bind(this));
    this.app.post('/api/credit/evaluate', this.evaluateCredit.bind(this));
    this.app.get('/api/evaluations/:id', this.getEvaluation.bind(this));
  }

  private setupEventHandlers(): void {
    this.eventBus.subscribe(
      'credit.evaluation.requested',
      async (event) => {
        const payload = event.payload as CreditEvaluationRequest;
        await this.processEvaluationRequest(payload);
      }
    );

    this.eventBus.subscribe(
      'loan.repayment.made',
      async (event) => {
        const payload = event.payload as { borrower: string; loanId: string; amount: number };
        await this.handleRepayment(payload.borrower, payload.amount);
      }
    );

    this.eventBus.subscribe(
      'loan.defaulted',
      async (event) => {
        const payload = event.payload as { borrower: string };
        await this.handleDefault(payload.borrower);
      }
    );

    this.eventBus.subscribe(
      'analytics.contribution.metrics',
      async (event) => {
        const payload = event.payload as { borrower: string; metrics: Record<string, number> };
        await this.updateContributionScore(payload.borrower, payload.metrics);
      }
    );

    this.eventBus.subscribe(
      'governance.proposal.vote.cast',
      async (event) => {
        const payload = event.payload as { voter: string; weight: number };
        await this.updateGovernanceScore(payload.voter, payload.weight);
      }
    );
  }

  /**
   * Get credit score for borrower
   */
  private async getCreditScore(req: Request, res: Response): Promise<void> {
    const { borrower } = req.params;

    let score = this.creditScores.get(borrower);

    if (!score) {
      score = this.calculateInitialScore(borrower);
      this.creditScores.set(borrower, score);
    }

    const response: ApiResponse<CreditScore> = {
      success: true,
      data: score,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Evaluate credit for loan request
   */
  private async evaluateCredit(req: Request, res: Response): Promise<void> {
    try {
      const evaluationRequest: CreditEvaluationRequest = req.body;

      const result = await this.performEvaluation(evaluationRequest);

      this.evaluations.set(result.creditScore.borrower + '_' + uuidv4(), result);

      await this.eventBus.publish({
        eventType: CreditEvents.EVALUATION_COMPLETED,
        source: 'credit-authority',
        payload: {
          borrower: evaluationRequest.borrower,
          evaluation: result,
        },
      });

      const response: ApiResponse<CreditEvaluationResult> = {
        success: true,
        data: result,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      res.json(response);
    } catch (error) {
      this.logger.error(`Error evaluating credit`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'EVALUATION_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get evaluation by ID
   */
  private async getEvaluation(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const evaluation = this.evaluations.get(id);

    if (!evaluation) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Evaluation not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    const response: ApiResponse<CreditEvaluationResult> = {
      success: true,
      data: evaluation,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Process evaluation request from loan engine
   */
  private async processEvaluationRequest(
    request: CreditEvaluationRequest
  ): Promise<void> {
    const result = await this.performEvaluation(request);

    await this.eventBus.publish({
      eventType: 'credit.score.updated',
      source: 'credit-authority',
      payload: {
        borrower: request.borrower,
        oldScore: this.creditScores.get(request.borrower)?.score || this.config.baseScore,
        newScore: result.creditScore.score,
        tier: result.creditScore.tier,
      },
    });
  }

  /**
   * Perform credit evaluation
   */
  private async performEvaluation(
    request: CreditEvaluationRequest
  ): Promise<CreditEvaluationResult> {
    let score = this.creditScores.get(request.borrower);

    if (!score) {
      score = this.calculateInitialScore(request.borrower);
      this.creditScores.set(request.borrower, score);
    }

    // Calculate debt-to-income ratio
    const estimatedMonthlyIncome = this.estimateMonthlyIncome(request.collateralAmount);
    const requestedMonthlyPayment = this.calculateMonthlyPayment(
      request.loanAmount,
      request.requestedInterestRate,
      12
    );
    const dtiRatio = requestedMonthlyPayment / estimatedMonthlyIncome;

    // Determine approval
    const approved = dtiRatio <= this.config.maxLoanToIncomeRatio && score.score >= this.config.minScore;

    // Calculate recommended rate
    const recommendedRate = this.calculateRecommendedRate(
      request.requestedInterestRate,
      score.tier
    );

    // Calculate max loan amount
    const maxLoanAmount = this.calculateMaxLoanAmount(
      estimatedMonthlyIncome,
      score.score
    );

    const riskRating = this.mapScoreToRiskRating(score.score);

    const conditions: string[] = [];
    if (dtiRatio > 0.28) {
      conditions.push('Consider lower loan amount to improve DTI ratio');
    }
    if (!request.collateralAmount) {
      conditions.push('Adding collateral could improve approval odds');
    }

    return {
      approved,
      recommendedRate,
      maxLoanAmount,
      riskRating,
      conditions,
      creditScore: score,
    };
  }

  /**
   * Calculate initial credit score
   */
  private calculateInitialScore(borrower: string): CreditScore {
    return {
      borrower,
      score: this.config.baseScore,
      tier: CreditTier.FAIR,
      factors: [
        {
          name: 'Base Score',
          impact: 0,
          description: 'Starting score for new borrowers',
        },
      ],
      history: [
        {
          date: new Date(),
          event: 'Account Created',
          impact: 0,
          newScore: this.config.baseScore,
        },
      ],
      lastUpdated: new Date(),
      calculationMethod: 'RCA_STANDARD_V1',
    };
  }

  /**
   * Estimate monthly income based on collateral
   */
  private estimateMonthlyIncome(collateralAmount?: number): number {
    if (collateralAmount) {
      return collateralAmount * 0.01;
    }
    return 5000;
  }

  /**
   * Calculate monthly loan payment
   */
  private calculateMonthlyPayment(
    principal: number,
    annualRate: number,
    termMonths: number
  ): number {
    const monthlyRate = annualRate / 100 / 12;
    const payment =
      (principal * monthlyRate * Math.pow(1 + monthlyRate, termMonths)) /
      (Math.pow(1 + monthlyRate, termMonths) - 1);
    return payment;
  }

  /**
   * Calculate recommended interest rate
   */
  private calculateRecommendedRate(
    requestedRate: number,
    tier: CreditTier
  ): number {
    const tierAdjustments: Record<CreditTier, number> = {
      [CreditTier.EXCELLENT]: -1.5,
      [CreditTier.GOOD]: -0.75,
      [CreditTier.FAIR]: 0,
      [CreditTier.POOR]: 1.0,
      [CreditTier.VERY_POOR]: 2.0,
    };

    return Math.max(0, requestedRate + (tierAdjustments[tier] || 0));
  }

  /**
   * Calculate maximum loan amount
   */
  private calculateMaxLoanAmount(monthlyIncome: number, creditScore: number): number {
    const baseMultiplier = creditScore >= 700 ? 36 : creditScore >= 600 ? 24 : 12;
    const dtiAllowance = monthlyIncome * this.config.maxLoanToIncomeRatio * 12;
    return Math.min(dtiAllowance * baseMultiplier, 1000000);
  }

  /**
   * Map credit score to risk rating
   */
  private mapScoreToRiskRating(score: number): RiskRating {
    if (score >= 800) return RiskRating.AAA;
    if (score >= 750) return RiskRating.AA;
    if (score >= 700) return RiskRating.A;
    if (score >= 650) return RiskRating.BBB;
    if (score >= 600) return RiskRating.BB;
    if (score >= 550) return RiskRating.B;
    if (score >= 500) return RiskRating.CCC;
    if (score >= 450) return RiskRating.CC;
    if (score >= 400) return RiskRating.C;
    return RiskRating.D;
  }

  /**
   * Update credit score based on repayment
   */
  private async handleRepayment(borrower: string, amount: number): Promise<void> {
    const score = this.creditScores.get(borrower);
    if (!score) return;

    const scoreIncrease = Math.min(20, amount / 1000);
    const newScore = Math.min(this.config.maxScore, score.score + scoreIncrease);

    this.updateScore(borrower, newScore, 'On-time repayment', scoreIncrease);
  }

  /**
   * Handle loan default
   */
  private async handleDefault(borrower: string): Promise<void> {
    const score = this.creditScores.get(borrower);
    if (!score) return;

    const scoreDecrease = 100;
    const newScore = Math.max(this.config.minScore, score.score - scoreDecrease);

    this.updateScore(borrower, newScore, 'Loan default', -scoreDecrease);

    await this.eventBus.publish({
      eventType: CreditEvents.RISK_ALERT,
      source: 'credit-authority',
      payload: {
        borrower,
        previousScore: score.score,
        newScore,
        alertType: 'DEFAULT',
      },
    });
  }

  /**
   * Update contribution score from GrowthFlow
   */
  private async updateContributionScore(
    borrower: string,
    metrics: Record<string, number>
  ): Promise<void> {
    const score = this.creditScores.get(borrower);
    if (!score) return;

    const contributionPoints =
      (metrics.communityContributions || 0) * 2 +
      (metrics代码Contributions || 0) * 3 +
      (metrics代码Reviews || 0);

    const scoreIncrease = Math.min(30, contributionPoints);
    const newScore = Math.min(this.config.maxScore, score.score + scoreIncrease);

    this.updateScore(borrower, newScore, 'Proof of Contribution', scoreIncrease);
  }

  /**
   * Update governance participation score
   */
  private async updateGovernanceScore(
    borrower: string,
    weight: number
  ): Promise<void> {
    const score = this.creditScores.get(borrower);
    if (!score) return;

    const scoreIncrease = Math.min(15, weight / 100);
    const newScore = Math.min(this.config.maxScore, score.score + scoreIncrease);

    this.updateScore(borrower, newScore, 'Governance Participation', scoreIncrease);
  }

  /**
   * Update credit score with new value
   */
  private updateScore(
    borrower: string,
    newScore: number,
    event: string,
    impact: number
  ): void {
    const score = this.creditScores.get(borrower)!;

    score.score = newScore;
    score.tier = this.mapScoreToTier(newScore);
    score.lastUpdated = new Date();

    score.factors.push({
      name: event,
      impact,
      description: `${event} affected score by ${impact > 0 ? '+' : ''}${impact} points`,
    });

    score.history.push({
      date: new Date(),
      event,
      impact,
      newScore,
    });

    this.creditScores.set(borrower, score);

    this.eventBus.publish({
      eventType: CreditEvents.SCORE_UPDATED,
      source: 'credit-authority',
      payload: {
        borrower,
        newScore,
        tier: score.tier,
      },
    });
  }

  /**
   * Map score to credit tier
   */
  private mapScoreToTier(score: number): CreditTier {
    if (score >= 750) return CreditTier.EXCELLENT;
    if (score >= 700) return CreditTier.GOOD;
    if (score >= 600) return CreditTier.FAIR;
    if (score >= 500) return CreditTier.POOR;
    return CreditTier.VERY_POOR;
  }

  /**
   * Start the service
   */
  start(): void {
    this.app.listen(this.config.port, () => {
      this.logger.info(`Credit Authority service started`, {
        port: this.config.port,
      });
    });
  }
}

export function createCreditAuthority(
  config?: Partial<CreditAuthorityConfig>
): CreditAuthority {
  return new CreditAuthority(config);
}

export default CreditAuthority;
