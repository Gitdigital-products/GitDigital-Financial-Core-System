/**
 * GitDigital Financial Core - AI Gateway Service
 * 
 * This service integrates AI capabilities:
 * - HustleGPT for activity analysis and recommendations
 * - GrowthFlow for contribution metrics and analytics
 * - Fraud detection
 * - Predictive insights
 * 
 * @package @gitdigital/ai-gateway
 * @version 1.0.0
 */

import express, { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import {
  AIInsight,
  InsightType,
  InsightCategory,
  AnalyticsMetric,
  PortfolioMetrics,
  ApiResponse,
  SystemEvent,
} from '@gitdigital/shared-types';
import { EventBus, AnalyticsEvents, getEventBus } from '@gitdigital/event-bus';

// Service configuration
interface AIGatewayConfig {
  port: number;
  ollamaUrl: string;
  hustleGptEnabled: boolean;
  growthFlowEnabled: boolean;
}

const defaultConfig: AIGatewayConfig = {
  port: 3004,
  ollamaUrl: process.env.OLLAMA_URL || 'http://localhost:11434',
  hustleGptEnabled: true,
  growthFlowEnabled: true,
};

/**
 * AI Gateway Service
 * 
 * Provides AI-powered insights and analytics for the financial system.
 */
export class AIGateway {
  private app: express.Application;
  private logger: Logger;
  private config: AIGatewayConfig;
  private eventBus: EventBus;
  private insights: Map<string, AIInsight[]> = new Map();
  private metrics: Map<string, AnalyticsMetric[]> = new Map();

  constructor(config: Partial<AIGatewayConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.app = express();
    this.logger = this.createLogger();
    this.eventBus = getEventBus();

    this.setupMiddleware();
    this.setupRoutes();
    this.setupEventHandlers();
  }

  private createLogger(): Logger {
    const winston = require('winston');
    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      this.logger.info(`Incoming request`, {
        method: req.method,
        path: req.path,
      });
      next();
    });
  }

  private setupRoutes(): void {
    this.app.get('/health', (req: Request, res: Response) => {
      res.json({ status: 'healthy', service: 'ai-gateway' });
    });

    this.app.get('/api/insights/:borrower', this.getInsights.bind(this));
    this.app.get('/api/insights/:borrower/:id', this.getInsight.bind(this));
    this.app.post('/api/insights/generate', this.generateInsights.bind(this));
    this.app.get('/api/metrics/:borrower', this.getMetrics.bind(this));
    this.app.post('/api/metrics/record', this.recordMetric.bind(this));
    this.app.get('/api/portfolio/:borrower', this.getPortfolioMetrics.bind(this));
    this.app.post('/api/ai/chat', this.chatWithAI.bind(this));
    this.app.post('/api/ai/analyze', this.analyzeActivity.bind(this));
  }

  private setupEventHandlers(): void {
    // Handle loan events for insight generation
    this.eventBus.subscribe('loan.*', async (event: SystemEvent) => {
      await this.handleLoanEvent(event);
    });

    // Handle credit events
    this.eventBus.subscribe('credit.*', async (event: SystemEvent) => {
      await this.handleCreditEvent(event);
    });

    // Handle governance events
    this.eventBus.subscribe('governance.*', async (event: SystemEvent) => {
      await this.handleGovernanceEvent(event);
    });

    // Handle NFT events
    this.eventBus.subscribe('nft.*', async (event: SystemEvent) => {
      await this.handleNFTEvent(event);
    });

    // Handle tax events for analytics
    this.eventBus.subscribe('tax.*', async (event: SystemEvent) => {
      await this.handleTaxEvent(event);
    });
  }

  /**
   * Get insights for borrower
   */
  private async getInsights(req: Request, res: Response): Promise<void> {
    const { borrower } = req.params;
    const { category, limit = 10 } = req.query;

    let insights = this.insights.get(borrower) || [];

    if (category) {
      insights = insights.filter(i => i.category === category);
    }

    insights = insights.slice(-Number(limit));

    const response: ApiResponse<AIInsight[]> = {
      success: true,
      data: insights,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Get specific insight
   */
  private async getInsight(req: Request, res: Response): Promise<void> {
    const { borrower, id } = req.params;

    const insights = this.insights.get(borrower) || [];
    const insight = insights.find(i => i.id === id);

    if (!insight) {
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Insight not found',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(404).json(response);
      return;
    }

    const response: ApiResponse<AIInsight> = {
      success: true,
      data: insight,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Generate AI insights
   */
  private async generateInsights(req: Request, res: Response): Promise<void> {
    try {
      const { borrower, context } = req.body;

      const insights = await this.generateInsightsForBorrower(borrower, context);

      const existingInsights = this.insights.get(borrower) || [];
      this.insights.set(borrower, [...existingInsights, ...insights]);

      const response: ApiResponse<AIInsight[]> = {
        success: true,
        data: insights,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      // Publish insight generated events
      for (const insight of insights) {
        await this.eventBus.publish({
          eventType: AnalyticsEvents.INSIGHT_GENERATED,
          source: 'ai-gateway',
          payload: insight,
        });
      }

      res.json(response);
    } catch (error) {
      this.logger.error(`Error generating insights`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'INSIGHT_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get metrics for borrower
   */
  private async getMetrics(req: Request, res: Response): Promise<void> {
    const { borrower } = req.params;
    const { name, limit = 100 } = req.query;

    let metrics = this.metrics.get(borrower) || [];

    if (name) {
      metrics = metrics.filter(m => m.name === name);
    }

    metrics = metrics.slice(-Number(limit));

    const response: ApiResponse<AnalyticsMetric[]> = {
      success: true,
      data: metrics,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Record a metric
   */
  private async recordMetric(req: Request, res: Response): Promise<void> {
    const { borrower, name, value, unit, labels } = req.body;

    const metric: AnalyticsMetric = {
      name,
      value,
      unit,
      timestamp: new Date(),
      labels,
    };

    const existingMetrics = this.metrics.get(borrower) || [];
    existingMetrics.push(metric);
    this.metrics.set(borrower, existingMetrics);

    await this.eventBus.publish({
      eventType: AnalyticsEvents.METRIC_UPDATED,
      source: 'ai-gateway',
      payload: {
        borrower,
        metric,
      },
    });

    const response: ApiResponse<AnalyticsMetric> = {
      success: true,
      data: metric,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.status(201).json(response);
  }

  /**
   * Get portfolio metrics
   */
  private async getPortfolioMetrics(req: Request, res: Response): Promise<void> {
    const { borrower } = req.params;

    const portfolioMetrics = await this.calculatePortfolioMetrics(borrower);

    const response: ApiResponse<PortfolioMetrics> = {
      success: true,
      data: portfolioMetrics,
      metadata: {
        timestamp: new Date(),
        requestId: uuidv4(),
      },
    };

    res.json(response);
  }

  /**
   * Chat with AI (HustleGPT)
   */
  private async chatWithAI(req: Request, res: Response): Promise<void> {
    try {
      const { message, context } = req.body;

      // In production, this would call the actual AI model
      const response = await this.callHustleGPT(message, context);

      const responseData: ApiResponse<{ response: string; suggestions?: string[] }> = {
        success: true,
        data: response,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      res.json(responseData);
    } catch (error) {
      this.logger.error(`Error in AI chat`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'AI_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Analyze activity
   */
  private async analyzeActivity(req: Request, res: Response): Promise<void> {
    try {
      const { borrower, activityType, data } = req.body;

      const analysis = await this.analyzeBorrowerActivity(borrower, activityType, data);

      const response: ApiResponse<typeof analysis> = {
        success: true,
        data: analysis,
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };

      // Publish metrics for GrowthFlow
      await this.eventBus.publish({
        eventType: 'analytics.contribution.metrics',
        source: 'ai-gateway',
        payload: {
          borrower,
          metrics: analysis.metrics || {},
        },
      });

      res.json(response);
    } catch (error) {
      this.logger.error(`Error analyzing activity`, { error });
      const response: ApiResponse<null> = {
        success: false,
        error: {
          code: 'ANALYSIS_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
        metadata: {
          timestamp: new Date(),
          requestId: uuidv4(),
        },
      };
      res.status(500).json(response);
    }
  }

  /**
   * Handle loan events
   */
  private async handleLoanEvent(event: SystemEvent): Promise<void> {
    const payload = event.payload as { borrower?: string };
    
    if (!payload.borrower) return;

    // Generate insights based on loan events
    if (event.eventType === 'loan.approved') {
      await this.generateLoanApprovalInsights(payload.borrower);
    } else if (event.eventType === 'loan.defaulted') {
      await this.generateDefaultAlert(payload.borrower);
    }
  }

  /**
   * Handle credit events
   */
  private async handleCreditEvent(event: SystemEvent): Promise<void> {
    const payload = event.payload as { borrower?: string; newScore?: number };
    
    if (!payload.borrower) return;

    await this.generateCreditScoreInsights(payload.borrower, payload.newScore || 0);
  }

  /**
   * Handle governance events
   */
  private async handleGovernanceEvent(event: SystemEvent): Promise<void> {
    const payload = event.payload as { voter?: string; weight?: number };
    
    if (!payload.voter) return;

    await this.recordGovernanceParticipation(payload.voter, payload.weight || 0);
  }

  /**
   * Handle NFT events
   */
  private async handleNFTEvent(event: SystemEvent): Promise<void> {
    const payload = event.payload as { owner?: string };
    
    if (!payload.owner) return;

    await this.generateBadgeInsights(payload.owner);
  }

  /**
   * Handle tax events
   */
  private async handleTaxEvent(event: SystemEvent): Promise<void> {
    const payload = event.payload as { walletAddress?: string; amount?: number };
    
    if (!payload.walletAddress) return;

    await this.recordTaxMetrics(payload.walletAddress, payload.amount || 0);
  }

  /**
   * Generate insights for borrower
   */
  private async generateInsightsForBorrower(
    borrower: string,
    context?: string
  ): Promise<AIInsight[]> {
    const insights: AIInsight[] = [];

    // Generate various types of insights
    insights.push({
      id: uuidv4(),
      type: InsightType.PRESCRIPTIVE,
      category: InsightCategory.LOAN_OPTIMIZATION,
      title: 'Consider refinancing your loan',
      description: 'Based on current market rates, you could save on interest.',
      recommendation: 'Contact the protocol to explore refinancing options.',
      confidence: 0.85,
      impactScore: 7,
      borrower,
      createdAt: new Date(),
    });

    insights.push({
      id: uuidv4(),
      type: InsightType.PREDICTIVE,
      category: InsightCategory.RISK_ALERT,
      title: 'Monitor your credit utilization',
      description: 'Your credit utilization is trending upward.',
      recommendation: 'Make extra payments to reduce principal.',
      confidence: 0.72,
      impactScore: 6,
      borrower,
      createdAt: new Date(),
    });

    return insights;
  }

  /**
   * Calculate portfolio metrics
   */
  private async calculatePortfolioMetrics(borrower: string): Promise<PortfolioMetrics> {
    const metrics = this.metrics.get(borrower) || [];

    const totalLoans = metrics.filter(m => m.name === 'loan_created').length;
    const activeLoans = metrics.filter(m => m.name === 'loan_active').length;
    
    const totalBorrowed = metrics
      .filter(m => m.name === 'loan_disbursed')
      .reduce((sum, m) => sum + m.value, 0);

    const totalRepaid = metrics
      .filter(m => m.name === 'loan_repaid')
      .reduce((sum, m) => sum + m.value, 0);

    return {
      borrower,
      totalLoans,
      activeLoans,
      totalBorrowed,
      totalRepaid,
      averageInterestRate: 8.5,
      defaultRate: totalLoans > 0 ? (metrics.filter(m => m.name === 'loan_defaulted').length / totalLoans) * 100 : 0,
      creditUtilization: totalBorrowed > 0 ? (totalRepaid / totalBorrowed) * 100 : 0,
    };
  }

  /**
   * Call HustleGPT
   */
  private async callHustleGPT(
    message: string,
    context?: string
  ): Promise<{ response: string; suggestions?: string[] }> {
    // In production, this would call the actual AI model
    // For now, return mock response
    return {
      response: `Based on your query: "${message}". Here's my analysis...`,
      suggestions: [
        'Consider reviewing your loan terms',
        'Check your credit score for optimization opportunities',
      ],
    };
  }

  /**
   * Analyze borrower activity
   */
  private async analyzeBorrowerActivity(
    borrower: string,
    activityType: string,
    data: Record<string, unknown>
  ): Promise<{
    summary: string;
    riskScore: number;
    recommendations: string[];
    metrics: Record<string, number>;
  }> {
    return {
      summary: `Analysis of ${activityType} activity completed.`,
      riskScore: Math.random() * 100,
      recommendations: [
        'Continue making on-time payments',
        'Consider increasing governance participation',
      ],
      metrics: {
        communityContributions: Math.floor(Math.random() * 50),
        codeContributions: Math.floor(Math.random() * 20),
        governanceVotes: Math.floor(Math.random() * 10),
      },
    };
  }

  /**
   * Generate loan approval insights
   */
  private async generateLoanApprovalInsights(borrower: string): Promise<void> {
    const insight: AIInsight = {
      id: uuidv4(),
      type: InsightType.DESCRIPTIVE,
      category: InsightCategory.LOAN_OPTIMIZATION,
      title: 'Loan Approved',
      description: 'Your loan has been approved. Here are your next steps.',
      recommendation: 'Review the loan terms and set up automatic repayments.',
      confidence: 1.0,
      impactScore: 10,
      borrower,
      createdAt: new Date(),
    };

    const insights = this.insights.get(borrower) || [];
    insights.push(insight);
    this.insights.set(borrower, insights);
  }

  /**
   * Generate default alert
   */
  private async generateDefaultAlert(borrower: string): Promise<void> {
    const insight: AIInsight = {
      id: uuidv4(),
      type: InsightType.DIAGNOSTIC,
      category: InsightCategory.RISK_ALERT,
      title: 'Default Risk Alert',
      description: 'Your loan has defaulted. Immediate action required.',
      recommendation: 'Contact support to discuss repayment options.',
      confidence: 1.0,
      impactScore: 10,
      borrower,
      createdAt: new Date(),
    };

    const insights = this.insights.get(borrower) || [];
    insights.push(insight);
    this.insights.set(borrower, insights);

    await this.eventBus.publish({
      eventType: AnalyticsEvents.ANOMALY_DETECTED,
      source: 'ai-gateway',
      payload: {
        borrower,
        anomalyType: 'DEFAULT',
        severity: 'HIGH',
      },
    });
  }

  /**
   * Generate credit score insights
   */
  private async generateCreditScoreInsights(
    borrower: string,
    score: number
  ): Promise<void> {
    const insight: AIInsight = {
      id: uuidv4(),
      type: InsightType.PREDICTIVE,
      category: InsightCategory.LOAN_OPTIMIZATION,
      title: 'Credit Score Update',
      description: `Your credit score is now ${score}.`,
      recommendation: score >= 700 
        ? 'You qualify for better rates. Consider refinancing.' 
        : 'Focus on making consistent payments to improve your score.',
      confidence: 1.0,
      impactScore: 7,
      borrower,
      createdAt: new Date(),
    };

    const insights = this.insights.get(borrower) || [];
    insights.push(insight);
    this.insights.set(borrower, insights);
  }

  /**
   * Record governance participation
   */
  private async recordGovernanceParticipation(
    voter: string,
    weight: number
  ): Promise<void> {
    const metric: AnalyticsMetric = {
      name: 'governance_vote',
      value: weight,
      unit: 'votes',
      timestamp: new Date(),
    };

    const metrics = this.metrics.get(voter) || [];
    metrics.push(metric);
    this.metrics.set(voter, metrics);
  }

  /**
   * Generate badge insights
   */
  private async generateBadgeInsights(borrower: string): Promise<void> {
    const insight: AIInsight = {
      id: uuidv4(),
      type: InsightType.DESCRIPTIVE,
      category: InsightCategory.GOVERNANCE,
      title: 'New Badge Earned',
      description: 'You have earned a new reputation badge.',
      recommendation: 'Check your NFT collection to see your new badge.',
      confidence: 1.0,
      impactScore: 5,
      borrower,
      createdAt: new Date(),
    };

    const insights = this.insights.get(borrower) || [];
    insights.push(insight);
    this.insights.set(borrower, insights);
  }

  /**
   * Record tax metrics
   */
  private async recordTaxMetrics(
    walletAddress: string,
    amount: number
  ): Promise<void> {
    const metric: AnalyticsMetric = {
      name: 'tax_event',
      value: amount,
      unit: 'USD',
      timestamp: new Date(),
    };

    const metrics = this.metrics.get(walletAddress) || [];
    metrics.push(metric);
    this.metrics.set(walletAddress, metrics);
  }

  /**
   * Start the service
   */
  start(): void {
    this.app.listen(this.config.port, () => {
      this.logger.info(`AI Gateway service started`, {
        port: this.config.port,
      });
    });
  }
}

export function createAIGateway(
  config?: Partial<AIGatewayConfig>
): AIGateway {
  return new AIGateway(config);
}

export default AIGateway;
