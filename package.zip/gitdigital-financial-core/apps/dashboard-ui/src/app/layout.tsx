import type { Metadata } from 'next';
import './globals.css';
import { Providers } from './providers';

export const metadata: Metadata = {
  title: 'GitDigital Financial Core',
  description: 'Decentralized Loan and Financial Infrastructure Platform',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-dark-900 text-dark-50">
        <Providers>
          <div className="min-h-screen flex">
            {/* Sidebar Navigation */}
            <aside className="w-64 bg-dark-800 border-r border-dark-700 hidden md:flex flex-col">
              <div className="p-6 border-b border-dark-700">
                <h1 className="text-xl font-bold text-primary-500">
                  GitDigital
                </h1>
                <p className="text-xs text-dark-400 mt-1">
                  Financial Core
                </p>
              </div>
              
              <nav className="flex-1 p-4 space-y-2">
                <NavLink href="/" icon="📊" label="Dashboard" />
                <NavLink href="/loans" icon="💳" label="Loans" />
                <NavLink href="/credit" icon="🛡️" label="Credit Score" />
                <NavLink href="/analytics" icon="🧠" label="AI Insights" />
                <NavLink href="/governance" icon="⚖️" label="Governance" />
                <NavLink href="/nfts" icon="🏅" label="Badges" />
                <NavLink href="/compliance" icon="🔐" label="Compliance" />
                <NavLink href="/tax" icon="🧾" label="Tax Reports" />
              </nav>

              <div className="p-4 border-t border-dark-700">
                <NavLink href="/settings" icon="⚙️" label="Settings" />
              </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 flex flex-col">
              {/* Header */}
              <header className="h-16 bg-dark-800 border-b border-dark-700 flex items-center justify-between px-6">
                <div className="flex items-center space-x-4">
                  <button className="md:hidden text-dark-400">
                    <span className="text-2xl">☰</span>
                  </button>
                  <h2 className="text-lg font-semibold text-dark-100">
                    Financial Dashboard
                  </h2>
                </div>

                <div className="flex items-center space-x-4">
                  <button className="p-2 text-dark-400 hover:text-dark-100 transition">
                    <span className="text-xl">🔔</span>
                  </button>
                  <div className="flex items-center space-x-2">
                    <WalletButton />
                  </div>
                </div>
              </header>

              {/* Page Content */}
              <div className="flex-1 p-6 overflow-auto">
                {children}
              </div>
            </main>
          </div>
        </Providers>
      </body>
    </html>
  );
}

function NavLink({ 
  href, 
  icon, 
  label 
}: { 
  href: string; 
  icon: string; 
  label: string;
}) {
  return (
    <a
      href={href}
      className="flex items-center space-x-3 px-4 py-3 rounded-lg text-dark-300 hover:text-dark-100 hover:bg-dark-700 transition"
    >
      <span className="text-xl">{icon}</span>
      <span className="font-medium">{label}</span>
    </a>
  );
}

function WalletButton() {
  return (
    <button className="flex items-center space-x-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 rounded-lg transition">
      <span>🔗</span>
      <span className="font-medium">Connect Wallet</span>
    </button>
  );
}
