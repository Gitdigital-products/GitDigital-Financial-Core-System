import './globals.css';

export default function Home() {
  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Loans"
          value="$124,500"
          change="+12.5%"
          icon="💳"
          positive
        />
        <StatCard
          title="Credit Score"
          value="742"
          change="+15 pts"
          icon="🛡️"
          positive
        />
        <StatCard
          title="Active Loans"
          value="3"
          change="0"
          icon="🔄"
        />
        <StatCard
          title="NFT Badges"
          value="7"
          change="+2"
          icon="🏅"
          positive
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Loan Status */}
        <div className="lg:col-span-2 bg-dark-800 rounded-xl p-6 border border-dark-700">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-dark-100">
              Active Loans
            </h3>
            <button className="px-4 py-2 bg-primary-600 hover:bg-primary-700 rounded-lg text-sm font-medium transition">
              + New Loan
            </button>
          </div>

          <div className="space-y-4">
            <LoanItem
              type="Founder Self-Loan"
              amount="$50,000"
              status="Active"
              progress={65}
              interest="8.5%"
            />
            <LoanItem
              type="Bridge Loan"
              amount="$25,000"
              status="Repaying"
              progress={40}
              interest="7.2%"
            />
            <LoanItem
              type="Collateralized"
              amount="$15,000"
              status="Funded"
              progress={20}
              interest="6.8%"
            />
          </div>
        </div>

        {/* AI Insights */}
        <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-dark-100">
              AI Insights
            </h3>
            <span className="text-secondary-400">🧠</span>
          </div>

          <div className="space-y-4">
            <InsightCard
              type="optimization"
              title="Refinance Opportunity"
              description="You could save $2,400/year by refinancing at current rates"
              confidence="92%"
            />
            <InsightCard
              type="alert"
              title="Payment Due Soon"
              description="Your next payment is due in 5 days"
              confidence="100%"
            />
            <InsightCard
              type="achievement"
              title="Credit Score Up!"
              description="Your score increased by 15 points this month"
              confidence="100%"
            />
          </div>
        </div>
      </div>

      {/* Bottom Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
          <h3 className="text-lg font-semibold text-dark-100 mb-6">
            Recent Transactions
          </h3>

          <div className="space-y-3">
            <TransactionItem
              type="loan_repayment"
              description="Loan Repayment"
              amount="-$1,250"
              date="2 hours ago"
            />
            <TransactionItem
              type="nft_mint"
              description="Badge Minted: Early Adopter"
              amount="0.05 SOL"
              date="1 day ago"
            />
            <TransactionItem
              type="governance"
              description="Governance Vote"
              amount="+5 pts"
              date="2 days ago"
            />
            <TransactionItem
              type="loan_funded"
              description="Loan Funded"
              amount="+$25,000"
              date="1 week ago"
            />
          </div>
        </div>

        {/* Compliance Status */}
        <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-dark-100">
              Compliance Status
            </h3>
            <span className="text-primary-500">✓ Verified</span>
          </div>

          <div className="space-y-4">
            <ComplianceItem
              status="verified"
              label="KYC Verification"
              description="Verified on Jan 15, 2026"
            />
            <ComplianceItem
              status="verified"
              label="AML Screening"
              description="Clear"
            />
            <ComplianceItem
              status="verified"
              label="Sanctions Check"
              description="No matches found"
            />
            <ComplianceItem
              status="pending"
              label="Tax Documents"
              description="2025 report pending"
            />
          </div>
        </div>
      </div>

      {/* System Health */}
      <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
        <h3 className="text-lg font-semibold text-dark-100 mb-6">
          System Services
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          <ServiceStatus name="Loan Engine" status="healthy" />
          <ServiceStatus name="Credit Auth" status="healthy" />
          <ServiceStatus name="AI Gateway" status="healthy" />
          <ServiceStatus name="Compliance" status="healthy" />
          <ServiceStatus name="Tax AI" status="healthy" />
          <ServiceStatus name="Infra Agent" status="healthy" />
          <ServiceStatus name="NFT Layer" status="degraded" />
        </div>
      </div>
    </div>
  );
}

function StatCard({
  title,
  value,
  change,
  icon,
  positive
}: {
  title: string;
  value: string;
  change: string;
  icon: string;
  positive?: boolean;
}) {
  return (
    <div className="bg-dark-800 rounded-xl p-6 border border-dark-700">
      <div className="flex items-center justify-between mb-4">
        <span className="text-2xl">{icon}</span>
        <span className={`text-sm font-medium ${positive ? 'text-primary-500' : 'text-dark-400'}`}>
          {change}
        </span>
      </div>
      <h3 className="text-dark-400 text-sm">{title}</h3>
      <p className="text-2xl font-bold text-dark-100 mt-1">{value}</p>
    </div>
  );
}

function LoanItem({
  type,
  amount,
  status,
  progress,
  interest
}: {
  type: string;
  amount: string;
  status: string;
  progress: number;
  interest: string;
}) {
  return (
    <div className="bg-dark-700 rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h4 className="font-medium text-dark-100">{type}</h4>
          <p className="text-dark-400 text-sm">{amount} @ {interest}</p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
          status === 'Active' ? 'bg-primary-500/20 text-primary-500' :
          status === 'Repaying' ? 'bg-secondary-500/20 text-secondary-500' :
          'bg-dark-500 text-dark-300'
        }`}>
          {status}
        </span>
      </div>
      <div className="w-full bg-dark-600 rounded-full h-2">
        <div 
          className="bg-primary-500 h-2 rounded-full transition-all"
          style={{ width: `${progress}%` }}
        />
      </div>
      <p className="text-dark-400 text-xs mt-2">{progress}% repaid</p>
    </div>
  );
}

function InsightCard({
  type,
  title,
  description,
  confidence
}: {
  type: string;
  title: string;
  description: string;
  confidence: string;
}) {
  const icons: Record<string, string> = {
    optimization: '💡',
    alert: '⚠️',
    achievement: '🎉',
  };

  const colors: Record<string, string> = {
    optimization: 'border-secondary-500/30 bg-secondary-500/10',
    alert: 'border-yellow-500/30 bg-yellow-500/10',
    achievement: 'border-primary-500/30 bg-primary-500/10',
  };

  return (
    <div className={`p-4 rounded-lg border ${colors[type]}`}>
      <div className="flex items-start space-x-3">
        <span className="text-xl">{icons[type]}</span>
        <div className="flex-1">
          <h4 className="font-medium text-dark-100 text-sm">{title}</h4>
          <p className="text-dark-400 text-xs mt-1">{description}</p>
          <span className="text-dark-500 text-xs mt-2 inline-block">
            {confidence} confidence
          </span>
        </div>
      </div>
    </div>
  );
}

function TransactionItem({
  type,
  description,
  amount,
  date
}: {
  type: string;
  description: string;
  amount: string;
  date: string;
}) {
  const icons: Record<string, string> = {
    loan_repayment: '💰',
    nft_mint: '🏅',
    governance: '⚖️',
    loan_funded: '💳',
  };

  return (
    <div className="flex items-center justify-between py-3 border-b border-dark-700 last:border-0">
      <div className="flex items-center space-x-3">
        <span className="text-xl">{icons[type]}</span>
        <div>
          <p className="text-dark-100 text-sm">{description}</p>
          <p className="text-dark-500 text-xs">{date}</p>
        </div>
      </div>
      <span className={`font-medium ${amount.startsWith('+') ? 'text-primary-500' : 'text-dark-100'}`}>
        {amount}
      </span>
    </div>
  );
}

function ComplianceItem({
  status,
  label,
  description
}: {
  status: string;
  label: string;
  description: string;
}) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-dark-700 last:border-0">
      <div>
        <p className="text-dark-100 text-sm">{label}</p>
        <p className="text-dark-500 text-xs">{description}</p>
      </div>
      <span className={`text-lg ${status === 'verified' ? 'text-primary-500' : 'text-yellow-500'}`}>
        {status === 'verified' ? '✓' : '⏳'}
      </span>
    </div>
  );
}

function ServiceStatus({
  name,
  status
}: {
  name: string;
  status: string;
}) {
  const colors: Record<string, string> = {
    healthy: 'bg-primary-500',
    degraded: 'bg-yellow-500',
    unhealthy: 'bg-red-500',
  };

  return (
    <div className="flex flex-col items-center p-3 bg-dark-700 rounded-lg">
      <div className={`w-3 h-3 rounded-full ${colors[status]} mb-2`} />
      <span className="text-dark-300 text-xs text-center">{name}</span>
    </div>
  );
}
