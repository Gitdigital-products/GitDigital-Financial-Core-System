/**
 * GitDigital Financial Core - Event Bus
 * 
 * This package implements the central event bus for system-wide
 * event communication between all services in the ecosystem.
 * 
 * @package @gitdigital/event-bus
 * @version 1.0.0
 */

import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';

// Type definitions for events
export interface SystemEvent {
  id: string;
  eventType: string;
  source: string;
  timestamp: Date;
  payload: unknown;
  metadata?: Record<string, unknown>;
}

export type EventHandler = (event: SystemEvent) => Promise<void>;

export interface EventSubscription {
  id: string;
  eventType: string;
  handler: EventHandler;
  options?: {
    correlationId?: string;
    filter?: (event: SystemEvent) => boolean;
  };
}

// Event bus configuration
export interface EventBusConfig {
  redis?: {
    host: string;
    port: number;
    password?: string;
  };
  rabbitmq?: {
    url: string;
  };
  enablePersistence: boolean;
  retryAttempts: number;
  retryDelay: number;
}

// Default configuration
const defaultConfig: EventBusConfig = {
  enablePersistence: true,
  retryAttempts: 3,
  retryDelay: 1000,
};

/**
 * Event Bus Implementation
 * 
 * Provides pub/sub functionality for system-wide events.
 * Supports both in-memory and distributed (Redis/RabbitMQ) modes.
 */
export class EventBus {
  private subscriptions: Map<string, EventSubscription[]> = new Map();
  private logger: Logger;
  private config: EventBusConfig;
  private eventHistory: SystemEvent[] = [];
  private readonly maxHistorySize = 1000;

  constructor(config: Partial<EventBusConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.logger = this.createLogger();
  }

  private createLogger(): Logger {
    const winston = require('winston');
    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      ]
    });
  }

  /**
   * Subscribe to an event type
   */
  subscribe(
    eventType: string,
    handler: EventHandler,
    options?: EventSubscription['options']
  ): string {
    const subscription: EventSubscription = {
      id: uuidv4(),
      eventType,
      handler,
      options,
    };

    if (!this.subscriptions.has(eventType)) {
      this.subscriptions.set(eventType, []);
    }

    this.subscriptions.get(eventType)!.push(subscription);
    
    this.logger.info(`Subscription created`, {
      subscriptionId: subscription.id,
      eventType,
    });

    return subscription.id;
  }

  /**
   * Unsubscribe from an event type
   */
  unsubscribe(subscriptionId: string): boolean {
    for (const [eventType, subs] of this.subscriptions.entries()) {
      const index = subs.findIndex(s => s.id === subscriptionId);
      if (index !== -1) {
        subs.splice(index, 1);
        this.logger.info(`Subscription removed`, {
          subscriptionId,
          eventType,
        });
        return true;
      }
    }
    return false;
  }

  /**
   * Publish an event to all subscribers
   */
  async publish(event: Omit<SystemEvent, 'id' | 'timestamp'>): Promise<void> {
    const fullEvent: SystemEvent = {
      ...event,
      id: uuidv4(),
      timestamp: new Date(),
    };

    // Store in history
    this.addToHistory(fullEvent);

    this.logger.info(`Event published`, {
      eventId: fullEvent.id,
      eventType: fullEvent.eventType,
      source: fullEvent.source,
    });

    // Get all subscriptions for this event type
    const subscriptions = this.subscriptions.get(fullEvent.eventType) || [];
    
    // Also notify wildcard subscribers
    const wildcardSubscriptions = this.subscriptions.get('*') || [];
    const allSubscriptions = [...subscriptions, ...wildcardSubscriptions];

    if (allSubscriptions.length === 0) {
      this.logger.warn(`No subscribers for event`, {
        eventType: fullEvent.eventType,
      });
    }

    // Notify all subscribers
    const promises = allSubscriptions.map(async (subscription) => {
      try {
        // Apply filter if specified
        if (subscription.options?.filter && !subscription.options.filter(fullEvent)) {
          return;
        }

        await this.executeWithRetry(() => subscription.handler(fullEvent));
      } catch (error) {
        this.logger.error(`Error in event handler`, {
          subscriptionId: subscription.id,
          eventType: fullEvent.eventType,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    await Promise.all(promises);
  }

  /**
   * Execute handler with retry logic
   */
  private async executeWithRetry(handler: EventHandler): Promise<void> {
    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= this.config.retryAttempts; attempt++) {
      try {
        await handler();
        return;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error('Unknown error');
        
        if (attempt < this.config.retryAttempts) {
          this.logger.warn(`Retrying event handler`, {
            attempt,
            maxAttempts: this.config.retryAttempts,
            delay: this.config.retryDelay,
            error: lastError.message,
          });
          
          await new Promise(resolve => 
            setTimeout(resolve, this.config.retryDelay * attempt)
          );
        }
      }
    }

    throw lastError;
  }

  /**
   * Add event to history
   */
  private addToHistory(event: SystemEvent): void {
    this.eventHistory.push(event);
    
    if (this.eventHistory.length > this.maxHistorySize) {
      this.eventHistory = this.eventHistory.slice(-this.maxHistorySize);
    }
  }

  /**
   * Get event history
   */
  getHistory(eventType?: string, limit = 100): SystemEvent[] {
    let events = this.eventHistory;

    if (eventType) {
      events = events.filter(e => e.eventType === eventType);
    }

    return events.slice(-limit);
  }

  /**
   * Clear event history
   */
  clearHistory(): void {
    this.eventHistory = [];
    this.logger.info(`Event history cleared`);
  }

  /**
   * Get subscription stats
   */
  getStats(): {
    totalSubscriptions: number;
    eventTypes: string[];
    historySize: number;
  } {
    let totalSubscriptions = 0;
    const eventTypes: string[] = [];

    for (const [eventType, subs] of this.subscriptions.entries()) {
      totalSubscriptions += subs.length;
      if (subs.length > 0) {
        eventTypes.push(eventType);
      }
    }

    return {
      totalSubscriptions,
      eventTypes,
      historySize: this.eventHistory.length,
    };
  }
}

// ============================================================================
// LOAN SYSTEM EVENTS
// ============================================================================

export const LoanEvents = {
  REQUESTED: 'loan.requested',
  APPROVED: 'loan.approved',
  REJECTED: 'loan.rejected',
  FUNDED: 'loan.funded',
  REPAID: 'loan.repaid',
  DEFAULTED: 'loan.defaulted',
  REPAYMENT_MADE: 'loan.repayment.made',
  COLLATERAL_DEPOSITED: 'loan.collateral.deposited',
  COLLATERAL_WITHDRAWN: 'loan.collateral.withdrawn',
};

// ============================================================================
// CREDIT AUTHORITY EVENTS
// ============================================================================

export const CreditEvents = {
  SCORE_UPDATED: 'credit.score.updated',
  EVALUATION_REQUESTED: 'credit.evaluation.requested',
  EVALUATION_COMPLETED: 'credit.evaluation.completed',
  RISK_ALERT: 'credit.risk.alert',
};

// ============================================================================
// GOVERNANCE EVENTS
// ============================================================================

export const GovernanceEvents = {
  PROPOSAL_CREATED: 'governance.proposal.created',
  PROPOSAL_VOTING_STARTED: 'governance.proposal.voting.started',
  PROPOSAL_VOTE cast: 'governance.proposal.vote.cast',
  PROPOSAL_PASSED: 'governance.proposal.passed',
  PROPOSAL_REJECTED: 'governance.proposal.rejected',
  PROPOSAL_EXECUTED: 'governance.proposal.executed',
};

// ============================================================================
// NFT EVENTS
// ============================================================================

export const NFTEvents = {
  MINTED: 'nft.minted',
  UPDATED: 'nft.updated',
  TRANSFERRED: 'nft.transferred',
  BURNED: 'nft.burned',
  BADGE_EARNED: 'nft.badge.earned',
};

// ============================================================================
// COMPLIANCE EVENTS
// ============================================================================

export const ComplianceEvents = {
  CHECK_REQUESTED: 'compliance.check.requested',
  CHECK_COMPLETED: 'compliance.check.completed',
  KYC_SUBMITTED: 'compliance.kyc.submitted',
  KYC_VERIFIED: 'compliance.kyc.verified',
  KYC_REJECTED: 'compliance.kyc.rejected',
  ALERT: 'compliance.alert',
};

// ============================================================================
// AI ANALYTICS EVENTS
// ============================================================================

export const AnalyticsEvents = {
  INSIGHT_GENERATED: 'analytics.insight.generated',
  ANOMALY_DETECTED: 'analytics.anomaly.detected',
  METRIC_UPDATED: 'analytics.metric.updated',
  REPORT_GENERATED: 'analytics.report.generated',
};

// ============================================================================
// TAX EVENTS
// ============================================================================

export const TaxEvents = {
  EVENT_LOGGED: 'tax.event.logged',
  REPORT_REQUESTED: 'tax.report.requested',
  REPORT_GENERATED: 'tax.report.generated',
};

// ============================================================================
// INFRASTRUCTURE EVENTS
// ============================================================================

export const InfraEvents = {
  SERVICE_DEPLOYED: 'infra.service.deployed',
  SERVICE_HEALTH_CHANGED: 'infra.service.health.changed',
  SCALING_TRIGGERED: 'infra.scaling.triggered',
  ERROR: 'infra.error',
};

// Singleton instance
let eventBusInstance: EventBus | null = null;

/**
 * Get the singleton EventBus instance
 */
export function getEventBus(config?: Partial<EventBusConfig>): EventBus {
  if (!eventBusInstance) {
    eventBusInstance = new EventBus(config);
  }
  return eventBusInstance;
}

/**
 * Create a new EventBus instance
 */
export function createEventBus(config?: Partial<EventBusConfig>): EventBus {
  return new EventBus(config);
}

export default EventBus;
