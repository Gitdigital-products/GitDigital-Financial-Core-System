/**
 * GitDigital Financial Core - Shared Types
 * 
 * This package contains TypeScript interfaces for the entire system,
 * including loan types, credit scoring, compliance, and event definitions.
 * 
 * @package @gitdigital/shared-types
 * @version 1.0.0
 */

// ============================================================================
// LOAN SYSTEM TYPES
// ============================================================================

export enum LoanStatus {
  DRAFT = 'DRAFT',
  APPLICATION_SUBMITTED = 'APPLICATION_SUBMITTED',
  KYC_PENDING = 'KYC_PENDING',
  KYC_VERIFIED = 'KYC_VERIFIED',
  CREDIT_EVALUATION = 'CREDIT_EVALUATION',
  UNDERWRITING = 'UNDERWRITING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  FUNDED = 'FUNDED',
  ACTIVE = 'ACTIVE',
  REPAYING = 'REPAYING',
  DEFAULTED = 'DEFAULTED',
  REPAID = 'REPAID',
  LIQUIDATED = 'LIQUIDATED'
}

export enum LoanType {
  FOUNDER_SELF_LOAN = 'FOUNDER_SELF_LOAN',
  COLLATERALIZED_LOAN = 'COLLATERALIZED_LOAN',
  UNSECURED_LOAN = 'UNSECURED_LOAN',
  BRIDGE_LOAN = 'BRIDGE_LOAN'
}

export interface LoanRequest {
  id: string;
  borrower: string;
  loanType: LoanType;
  principalAmount: number;
  collateralAmount?: number;
  collateralToken?: string;
  interestRate: number;
  termMonths: number;
  purpose: string;
  status: LoanStatus;
  createdAt: Date;
  updatedAt: Date;
  governanceProposalId?: string;
  creditScore?: number;
  riskRating?: RiskRating;
}

export interface LoanRepayment {
  id: string;
  loanId: string;
  amount: number;
  principalPaid: number;
  interestPaid: number;
  penaltyPaid: number;
  paymentDate: Date;
  transactionHash: string;
  status: RepaymentStatus;
}

export enum RepaymentStatus {
  PENDING = 'PENDING',
  CONFIRMED = 'CONFIRMED',
  FAILED = 'FAILED',
  PARTIAL = 'PARTIAL'
}

export enum RiskRating {
  AAA = 'AAA',
  AA = 'AA',
  A = 'A',
  BBB = 'BBB',
  BB = 'BB',
  B = 'B',
  CCC = 'CCC',
  CC = 'CC',
  C = 'C',
  D = 'D'
}

// ============================================================================
// CREDIT AUTHORITY TYPES
// ============================================================================

export interface CreditScore {
  borrower: string;
  score: number;
  tier: CreditTier;
  factors: CreditFactor[];
  history: CreditHistoryEntry[];
  lastUpdated: Date;
  calculationMethod: string;
}

export enum CreditTier {
  EXCELLENT = 'EXCELLENT',
  GOOD = 'GOOD',
  FAIR = 'FAIR',
  POOR = 'POOR',
  VERY_POOR = 'VERY_POOR'
}

export interface CreditFactor {
  name: string;
  impact: number;
  description: string;
}

export interface CreditHistoryEntry {
  date: Date;
  event: string;
  impact: number;
  newScore: number;
}

export interface CreditEvaluationRequest {
  borrower: string;
  loanAmount: number;
  loanPurpose: string;
  requestedInterestRate: number;
  collateralAmount?: number;
}

export interface CreditEvaluationResult {
  approved: boolean;
  recommendedRate: number;
  maxLoanAmount: number;
  riskRating: RiskRating;
  conditions: string[];
  creditScore: CreditScore;
}

// ============================================================================
// GOVERNANCE TYPES
// ============================================================================

export interface GovernanceProposal {
  id: string;
  title: string;
  description: string;
  proposalType: ProposalType;
  status: ProposalStatus;
  proposer: string;
  votingStart: Date;
  votingEnd: Date;
  forVotes: number;
  againstVotes: number;
  abstainVotes: number;
  quorum: number;
  executedAt?: Date;
  executedBy?: string;
}

export enum ProposalType {
  PARAMETER_CHANGE = 'PARAMETER_CHANGE',
  EMERGENCY_STOP = 'EMERGENCY_STOP',
  NEW_COLLATERAL = 'NEW_COLLATERAL',
  PROTOCOL_UPGRADE = 'PROTOCOL_UPGRADE',
  CREDIT_POLICY_CHANGE = 'CREDIT_POLICY_CHANGE'
}

export enum ProposalStatus {
  DRAFT = 'DRAFT',
  SUBMITTED = 'SUBMITTED',
  VOTING = 'VOTING',
  PASSED = 'PASSED',
  REJECTED = 'REJECTED',
  EXECUTED = 'EXECUTED',
  EXPIRED = 'EXPIRED'
}

export interface Vote {
  proposalId: string;
  voter: string;
  choice: VoteChoice;
  weight: number;
  timestamp: Date;
}

export enum VoteChoice {
  FOR = 'FOR',
  AGAINST = 'AGAINST',
  ABSTAIN = 'ABSTAIN'
}

// ============================================================================
// DYNAMIC NFT TYPES
// ============================================================================

export interface DynamicNFT {
  id: string;
  mintAddress: string;
  owner: string;
  loanId?: string;
  badgeType: BadgeType;
  level: number;
  experience: number;
  attributes: NFTAttribute[];
  metadata: NFTStructuredMetadata;
  lastUpdated: Date;
  imageUri: string;
}

export enum BadgeType {
  FOUNDER = 'FOUNDER',
  EARLY_ADOPTER = 'EARLY_ADOPTER',
  VERIFIED_BORROWER = 'VERIFIED_BORROWER',
  REPUTATION_BUILDER = 'REPUTATION_BUILDER',
  GOVERNANCE_PARTICIPANT = 'GOVERNANCE_PARTICIPANT',
  CREDIT_CHAMPION = 'CREDIT_CHAMPION'
}

export interface NFTAttribute {
  trait_type: string;
  value: string | number;
  display_type?: string;
}

export interface NFTStructuredMetadata {
  name: string;
  description: string;
  image: string;
  external_url: string;
  attributes: NFTAttribute[];
  properties: {
    files: { uri: string; type: string }[];
    category: string;
  };
}

export interface ReputationScore {
  borrower: string;
  totalScore: number;
  loanRepaymentScore: number;
  governanceParticipationScore: number;
  communityContributionScore: number;
  badgeScore: number;
  lastUpdated: Date;
}

// ============================================================================
// COMPLIANCE TYPES
// ============================================================================

export interface KYCVerification {
  id: string;
  walletAddress: string;
  status: KYCStatus;
  riskLevel: RiskLevel;
  verifiedAt?: Date;
  expiresAt?: Date;
  documentIds: string[];
  checks: KYCCheck[];
}

export enum KYCStatus {
  NOT_STARTED = 'NOT_STARTED',
  PENDING = 'PENDING',
  IN_REVIEW = 'IN_REVIEW',
  VERIFIED = 'VERIFIED',
  REJECTED = 'REJECTED',
  EXPIRED = 'EXPIRED'
}

export enum RiskLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  PROHIBITED = 'PROHIBITED'
}

export interface KYCCheck {
  checkType: string;
  status: 'PASS' | 'FAIL' | 'PENDING';
  details?: string;
  timestamp: Date;
}

export interface ComplianceValidationRequest {
  walletAddress: string;
  action: ComplianceAction;
  metadata?: Record<string, unknown>;
}

export interface ComplianceValidationResult {
  allowed: boolean;
  reason?: string;
  riskLevel: RiskLevel;
  checks: KYCCheck[];
}

export enum ComplianceAction {
  LOAN_REQUEST = 'LOAN_REQUEST',
  LOAN_REPAYMENT = 'LOAN_REPAYMENT',
  COLLATERAL_DEPOSIT = 'COLLATERAL_DEPOSIT',
  COLLATERAL_WITHDRAWAL = 'COLLATERAL_WITHDRAWAL',
  GOVERNANCE_VOTE = 'GOVERNANCE_VOTE',
  NFT_MINT = 'NFT_MINT',
  NFT_TRANSFER = 'NFT_TRANSFER'
}

// ============================================================================
// AI & ANALYTICS TYPES
// ============================================================================

export interface AIInsight {
  id: string;
  type: InsightType;
  category: InsightCategory;
  title: string;
  description: string;
  recommendation: string;
  confidence: number;
  impactScore: number;
  borrower?: string;
  createdAt: Date;
  metadata?: Record<string, unknown>;
}

export enum InsightType {
  PREDICTIVE = 'PREDICTIVE',
  PRESCRIPTIVE = 'PRESCRIPTIVE',
  DIAGNOSTIC = 'DIAGNOSTIC',
  DESCRIPTIVE = 'DESCRIPTIVE'
}

export enum InsightCategory {
  LOAN_OPTIMIZATION = 'LOAN_OPTIMIZATION',
  RISK_ALERT = 'RISK_ALERT',
  REPAYMENT_STRATEGY = 'REPAYMENT_STRATEGY',
  COLLATERAL_MANAGEMENT = 'COLLATERAL_MANAGEMENT',
  GOVERNANCE = 'GOVERNANCE',
  COMPLIANCE = 'COMPLIANCE'
}

export interface AnalyticsMetric {
  name: string;
  value: number;
  unit: string;
  timestamp: Date;
  labels?: Record<string, string>;
}

export interface PortfolioMetrics {
  borrower: string;
  totalLoans: number;
  activeLoans: number;
  totalBorrowed: number;
  totalRepaid: number;
  averageInterestRate: number;
  defaultRate: number;
  creditUtilization: number;
}

// ============================================================================
// TAX TYPES
// ============================================================================

export interface TaxEvent {
  id: string;
  walletAddress: string;
  eventType: TaxEventType;
  amount: number;
  token: string;
  usdValue: number;
  transactionHash: string;
  timestamp: Date;
  taxYear: number;
}

export enum TaxEventType {
  LOAN_DISBURSEMENT = 'LOAN_DISBURSEMENT',
  LOAN_REPAYMENT = 'LOAN_REPAYMENT',
  INTEREST_PAYMENT = 'INTEREST_PAYMENT',
  COLLATERAL_DEPOSIT = 'COLLATERAL_DEPOSIT',
  COLLATERAL_WITHDRAWAL = 'COLLATERAL_WITHDRAWAL',
  NFT_MINT = 'NFT_MINT',
  NFT_SALE = 'NFT_SALE',
  GOVERNANCE_REWARD = 'GOVERNANCE_REWARD'
}

export interface TaxReport {
  id: string;
  walletAddress: string;
  taxYear: number;
  generatedAt: Date;
  events: TaxEvent[];
  totalIncome: number;
  totalExpenses: number;
  netGainLoss: number;
  format: TaxReportFormat;
}

export enum TaxReportFormat {
  CSV = 'CSV',
  PDF = 'PDF',
  JSON = 'JSON'
}

// ============================================================================
// EVENT SYSTEM TYPES
// ============================================================================

export interface SystemEvent {
  id: string;
  eventType: string;
  source: string;
  timestamp: Date;
  payload: unknown;
  metadata?: Record<string, unknown>;
}

// Loan Events
export interface LoanRequestedEvent extends SystemEvent {
  eventType: 'loan.requested';
  payload: {
    loanId: string;
    borrower: string;
    amount: number;
  };
}

export interface LoanApprovedEvent extends SystemEvent {
  eventType: 'loan.approved';
  payload: {
    loanId: string;
    borrower: string;
    interestRate: number;
    riskRating: RiskRating;
  };
}

export interface LoanFundedEvent extends SystemEvent {
  eventType: 'loan.funded';
  payload: {
    loanId: string;
    borrower: string;
    amount: number;
    transactionHash: string;
  };
}

// Credit Events
export interface CreditScoreUpdatedEvent extends SystemEvent {
  eventType: 'credit.score.updated';
  payload: {
    borrower: string;
    oldScore: number;
    newScore: number;
    tier: CreditTier;
  };
}

// Compliance Events
export interface ComplianceCheckEvent extends SystemEvent {
  eventType: 'compliance.check';
  payload: {
    walletAddress: string;
    action: ComplianceAction;
    result: ComplianceValidationResult;
  };
}

// NFT Events
export interface NFTMintedEvent extends SystemEvent {
  eventType: 'nft.minted';
  payload: {
    mintAddress: string;
    owner: string;
    badgeType: BadgeType;
    loanId?: string;
  };
}

export interface NFTUpdatedEvent extends SystemEvent {
  eventType: 'nft.updated';
  payload: {
    mintAddress: string;
    attributes: NFTAttribute[];
  };
}

// ============================================================================
// INFRASTRUCTURE TYPES
// ============================================================================

export interface ServiceHealth {
  serviceName: string;
  status: ServiceStatus;
  uptime: number;
  lastCheck: Date;
  responseTime: number;
  errorRate: number;
}

export enum ServiceStatus {
  HEALTHY = 'HEALTHY',
  DEGRADED = 'DEGRADED',
  UNHEALTHY = 'UNHEALTHY',
  UNKNOWN = 'UNKNOWN'
}

export interface DeploymentConfig {
  serviceName: string;
  environment: 'development' | 'staging' | 'production';
  version: string;
  replicas: number;
  resources: {
    cpu: string;
    memory: string;
  };
  autoscaling?: {
    minReplicas: number;
    maxReplicas: number;
    targetCpuUtilization: number;
  };
}

// ============================================================================
// API RESPONSE TYPES
// ============================================================================

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: ApiError;
  metadata?: {
    timestamp: Date;
    requestId: string;
  };
}

export interface ApiError {
  code: string;
  message: string;
  details?: unknown;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}
