%% ============================================
%% GITDIGITAL PRODUCTS - SYSTEM ARCHITECTURE FLOWCHART
%% ============================================
flowchart LR
    %% ============================================
    %% STYLING DEFINITIONS
    %% ============================================
    classDef gitProd fill:#1e3a5f,stroke:#4da3ff,color:#e8f1ff
    classDef rick fill:#5a3a00,stroke:#ffb84d,color:#ffeccc
    classDef analytics fill:#2d3b2d,stroke:#66cc66,color:#eaffea
    classDef compliance fill:#3a2d2d,stroke:#ff6666,color:#ffeaea
    classDef infra fill:#2f2f2f,stroke:#999,color:#eee
    classDef repo fill:#0d1117,stroke:#58a6ff,color:#c9d1d9
    classDef githubApp fill:#24292f,stroke:#f0f6fc,color:#ffffff
    classDef dashed stroke:#888,stroke-dasharray: 5 3

    %% ============================================
    %% CORE LOAN SYSTEM - Gitdigital-products
    %% ============================================
    subgraph CoreSystem["Core Loan System (Gitdigital-products)"]
        direction LR
        LoanCore["💳 Loan System / Founder Self-Loan"]
        WorkflowEngine["🔄 Loan Workflow Engine"]
        GovernanceEngine["⚖️ Governance Engine"]
        NFTDynamic["🏅 Dynamic NFT / Badge Layer"]
        UILayer["🖥️ User Interface Layer"]
    end
    class LoanCore,WorkflowEngine,GovernanceEngine,NFTDynamic,UILayer gitProd

    %% ============================================
    %% CORE REPOSITORIES
    %% ============================================
    subgraph CoreRepos["Core System Repositories"]
        direction TB
        Repo_FounderLoan["📦 Founder-Self-Loan"]
        Repo_Governance["📦 RDK-GDP-LOAN-GOVERNANCE"]
        Repo_DNFT["📦 Dynamic-NFT-dNFT-Framework"]
        Repo_UI["📦 User-Interface-React-API-Layer"]
    end
    class Repo_FounderLoan,Repo_Governance,Repo_DNFT,Repo_UI repo

    %% ============================================
    %% CREDIT AUTHORITY - RickCreator87
    %% ============================================
    subgraph CreditAuth["Credit Authority Layer"]
        direction LR
        CreditAuthority["🛡️ Richards Credit Authority"]
    end
    class CreditAuthority rick

    %% ============================================
    %% CREDIT AUTHORITY REPOSITORIES
    %% ============================================
    subgraph CreditRepos["Credit Authority Repositories"]
        direction TB
        Repo_CreditAuth["📦 richards-credit-authority"]
        Repo_SaaS["📦 SaaS-banking-and-loaning"]
        Repo_Badge["📦 BADGE-AUTHORITY"]
    end
    class Repo_CreditAuth,Repo_SaaS,Repo_Badge repo

    %% ============================================
    %% AI + ANALYTICS LAYER
    %% ============================================
    subgraph Intelligence["AI + Analytics Layer"]
        direction LR
        AI_Gateway["🧠 AI Gateway + Analytics"]
        HustleGPT_App["🤖 HustleGPT"]
        GrowthFlow_App["📈 GrowthFlow"]
    end
    class AI_Gateway,HustleGPT_App,GrowthFlow_App analytics

    %% ============================================
    %% AI + ANALYTICS REPOSITORIES
    %% ============================================
    subgraph AI_Repos["AI + Analytics Repositories"]
        direction TB
        Repo_AIGateway["📦 AIGateway-Ollama"]
        Repo_Analytics["📦 analytics-service"]
        Repo_ProofContrib["📦 Proof-of-Contribution-Protocol-Core"]
    end
    class Repo_AIGateway,Repo_Analytics,Repo_ProofContrib repo

    %% ============================================
    %% COMPLIANCE + TAX LAYER
    %% ============================================
    subgraph ComplianceTax["Compliance + Tax Layer"]
        direction LR
        ComplianceGuard["🔐 Solana Compliance Guard"]
        TaxAI_App["🧾 Tax AI"]
    end
    class ComplianceGuard,TaxAI_App compliance

    %% ============================================
    %% COMPLIANCE REPOSITORIES
    %% ============================================
    subgraph ComplianceRepos["Compliance Repositories"]
        direction TB
        Repo_KYC["📦 solana-kyc-compliance-sdk"]
        Repo_KYC_AML["📦 Identity-Verification-KYC-AML"]
        Repo_ComplianceReg["📦 solana-compliance-registry"]
        Repo_Fraud["📦 fraud-detection-service"]
    end
    class Repo_KYC,Repo_KYC_AML,Repo_ComplianceReg,Repo_Fraud repo

    %% ============================================
    %% INFRASTRUCTURE LAYER
    %% ============================================
    subgraph InfraLayer["Infrastructure Layer"]
        direction LR
        Infra_Agent["🛠️ Infra Agent"]
        R_Deployer["📊 R Deployer"]
        LedgerX["📒 Ledger-X"]
    end
    class Infra_Agent,R_Deployer,LedgerX infra

    %% ============================================
    %% INFRASTRUCTURE REPOSITORIES
    %% ============================================
    subgraph InfraRepos["Infrastructure Repositories"]
        direction TB
        Repo_Infra["📦 GITDIGITAL-FINANCIAL-INFRASTRUCTURE"]
        Repo_Node["📦 Node-Software-Full-Light"]
        Repo_Client["📦 Client-library-blockchain"]
        Repo_DeFi["📦 Decentralized-Finance-DeFi-Primitives"]
    end
    class Repo_Infra,Repo_Node,Repo_Client,Repo_DeFi repo

    %% ============================================
    %% ADDITIONAL SERVICES
    %% ============================================
    subgraph AdditionalServices["Additional Services"]
        direction LR
        Repo_Fix["🔧 Repo-fix"]
        EmojiLib["😀 Emoji Library"]
        Swarmbots["🤖 Swarmbots"]
        SRAM["🎮 SRAM"]
        Loyalty["🎁 Loyalty Service"]
        TokenStd["🪙 Token Standards"]
    end
    class Repo_Fix,EmojiLib,Swarmbots,SRAM,Loyalty,TokenStd repo

    %% ============================================
    %% GITHUB APPS
    %% ============================================
    subgraph GitHubApps["GitHub Apps"]
        direction LR
        App_InfraAgent["🔧 infra-agent"]
        App_HustleGPT["🤖 HustleGPT"]
        App_RDeployer["📊 R-deployer"]
        App_GrowthFlow["📈 Growthflow"]
        App_LedgerX["📒 Ledger-X"]
        App_Compliance["🔐 Solana Compliance Guard"]
        App_RepoFix["🔧 Repo-fix"]
        App_TaxAI["🧾 Tax AI"]
    end
    class App_InfraAgent,App_HustleGPT,App_RDeployer,App_GrowthFlow,App_LedgerX,App_Compliance,App_RepoFix,App_TaxAI githubApp

    %% ============================================
    %% EVENT FLOWS - CORE LOAN SYSTEM
    %% ============================================
    LoanCore -- "loan.requested" --> WorkflowEngine
    WorkflowEngine -- "workflow.updated" --> GovernanceEngine
    GovernanceEngine -- "policy.approved" --> NFTDynamic
    NFTDynamic -- "nft.minted / reputation.updated" --> UILayer

    %% ============================================
    %% EVENT FLOWS - CREDIT AUTHORITY
    %% ============================================
    LoanCore -- "loan.evaluation" --> CreditAuthority
    GrowthFlow_App -- "contribution.metrics" --> CreditAuthority
    HustleGPT_App -- "activity.analysis" --> CreditAuthority
    CreditAuthority -- "credit.score.updated" --> GovernanceEngine
    CreditAuthority -- "credit.score.updated" --> NFTDynamic

    %% ============================================
    %% EVENT FLOWS - AI OBSERVATIONAL
    %% ============================================
    WorkflowEngine -.->|loan events| AI_Gateway
    GovernanceEngine -.->|policy events| AI_Gateway
    NFTDynamic -.->|NFT / reputation| AI_Gateway
    CreditAuthority -.->|credit updates| AI_Gateway

    %% ============================================
    %% EVENT FLOWS - COMPLIANCE
    %% ============================================
    LoanCore -- "loan.validate" --> ComplianceGuard
    GovernanceEngine -- "policy.validate" --> ComplianceGuard
    WorkflowEngine -- "workflow.validate" --> ComplianceGuard
    NFTDynamic -- "NFT.validate" --> ComplianceGuard
    ComplianceGuard -- "deployment.safe" --> Infra_Agent

    %% ============================================
    %% EVENT FLOWS - INFRASTRUCTURE DEPLOYMENT
    %% ============================================
    Infra_Agent -- "deploy.approved" --> LoanCore
    Infra_Agent -- "deploy.approved" --> GovernanceEngine
    Infra_Agent -- "deploy.approved" --> NFTDynamic
    Infra_Agent -- "deploy.approved" --> AI_Gateway
    Infra_Agent -- "deploy.approved" --> UILayer
    Infra_Agent -- "deploy.approved" --> WorkflowEngine

    %% ============================================
    %% TAX AI REPORTING
    %% ============================================
    TaxAI_App -.->|audit reports| AI_Gateway
    ComplianceGuard -- "tax.reports" --> TaxAI_App

    %% ============================================
    %% REPOSITORY CONNECTIONS
    %% ============================================
    Repo_FounderLoan --> LoanCore
    Repo_Governance --> GovernanceEngine
    Repo_DNFT --> NFTDynamic
    Repo_UI --> UILayer
    
    Repo_CreditAuth --> CreditAuthority
    Repo_SaaS --> CreditAuthority
    Repo_Badge --> NFTDynamic
    
    Repo_AIGateway --> AI_Gateway
    Repo_Analytics --> GrowthFlow_App
    Repo_ProofContrib --> CreditAuthority
    
    Repo_KYC --> ComplianceGuard
    Repo_KYC_AML --> ComplianceGuard
    Repo_ComplianceReg --> ComplianceGuard
    Repo_Fraud --> ComplianceGuard
    
    Repo_Infra --> Infra_Agent
    Repo_Node --> Infra_Agent
    Repo_Client --> Infra_Agent
    Repo_DeFi --> Infra_Agent

    %% ============================================
    %% GITHUB APP CONNECTIONS
    %% ============================================
    App_InfraAgent -.->|manages| Infra_Agent
    App_HustleGPT -.->|powers| HustleGPT_App
    App_RDeployer -.->|deploys to| Infra_Agent
    App_GrowthFlow -.->|feeds| GrowthFlow_App
    App_LedgerX -.->|integrates with| Infra_Agent
    App_Compliance -.->|enforces| ComplianceGuard
    App_RepoFix -.->|maintains repos| InfraRepos
    App_TaxAI -.->|powers| TaxAI_App